package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.Category
import com.example.data.Product
import com.example.data.Invoice
import com.example.data.InvoiceItem
import com.example.utils.ReceiptPrinterHelper
import kotlinx.coroutines.launch
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import java.text.SimpleDateFormat
import java.util.Date
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

// --- Helper: Format currency in Iraqi Dinars ---
fun formatIraqiDinar(amount: Double): String {
    val df = java.text.DecimalFormat("#,###", java.text.DecimalFormatSymbols(java.util.Locale.ENGLISH))
    return "${df.format(amount.toLong())} د.ع"
}

// --- Helper: Get image resource safely by string name or URI ---
@Composable
fun getProductImagePainter(imageName: String): Painter {
    val context = LocalContext.current
    if (imageName.startsWith("content://") || imageName.startsWith("file://")) {
        return coil.compose.rememberAsyncImagePainter(
            model = coil.request.ImageRequest.Builder(context)
                .data(imageName)
                .crossfade(true)
                .build()
        )
    }

    val resId = remember(imageName) {
        var id = context.resources.getIdentifier(imageName, "drawable", context.packageName)
        if (id == 0) {
            // Try to match partial names
            id = when {
                imageName.contains("grill") -> R.drawable.img_grill_1784408854318
                imageName.contains("burger") -> R.drawable.img_burger_1784408864721
                imageName.contains("pizza") -> R.drawable.img_pizza_1784408876158
                imageName.contains("drink") -> R.drawable.img_drink_1784408886919
                else -> R.drawable.img_grill_1784408854318
            }
        }
        id
    }
    return painterResource(id = resId)
}

// --- Dialog: POS Payment Interface (واجهة الدفع) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentDialog(
    viewModel: POSViewModel,
    onDismiss: () -> Unit,
    onPaymentSuccess: (Long) -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val totalAmount by viewModel.cartTotalAmount.collectAsStateWithLifecycle()
    val paymentMethod by viewModel.paymentMethod.collectAsStateWithLifecycle()
    val amountReceivedText by viewModel.amountReceivedText.collectAsStateWithLifecycle()
    val amountReceived by viewModel.amountReceived.collectAsStateWithLifecycle()
    val amountChange by viewModel.amountChange.collectAsStateWithLifecycle()
    val orderType by viewModel.orderType.collectAsStateWithLifecycle()
    val isPOSOpen by viewModel.isPOSOpen.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val orderTypeDetails by viewModel.orderTypeDetails.collectAsStateWithLifecycle()
    val customerAddress by viewModel.customerAddress.collectAsStateWithLifecycle()
    val deliveryPriceType by viewModel.deliveryPriceType.collectAsStateWithLifecycle()
    val deliveryFee by viewModel.deliveryFee.collectAsStateWithLifecycle()

    // Direct printing used instead of preview

    val scope = rememberCoroutineScope()
    var isCheckingPrinters by remember { mutableStateOf(false) }
    var printerErrorToShow by remember { mutableStateOf<String?>(null) }


    val mainPrinterMac by viewModel.mainPrinterMac.collectAsStateWithLifecycle()
    val kitchenPrinterMac by viewModel.kitchenPrinterMac.collectAsStateWithLifecycle()
    val mainPrinterName by viewModel.printerName.collectAsStateWithLifecycle()
    val kitchenPrinterName by viewModel.selectedKitchenPrinterName.collectAsStateWithLifecycle()
    val isKitchenPrinterEnabled by viewModel.isKitchenPrinterEnabled.collectAsStateWithLifecycle()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .wrapContentHeight()
                    .padding(16.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = POSSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "إتمام الدفع وتسجيل الفاتورة",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Shift Block Warning
                    if (!isPOSOpen) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = POSDanger.copy(alpha = 0.1f)),
                            border = BorderStroke(1.dp, POSDanger)
                        ) {
                            Text(
                                text = "تنبيه: لا توجد نقطة بيع مفتوحة حالياً! يرجى فتح نقطة البيع من الإعدادات لإتمام عملية المبيعات.",
                                fontSize = 13.sp,
                                color = POSDanger,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Total Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                        border = BorderStroke(1.dp, POSBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المبلغ المطلوب للفاتورة",
                                fontSize = 16.sp,
                                color = TextMuted
                            )
                            Text(
                                text = formatIraqiDinar(totalAmount),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = POSPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Service Type (dine-in / takeaway / delivery)
                    Text(
                        text = "نوع الطلب (الخدمة)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Dine-in Option
                        val isDineIn = orderType == "صالة"
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clickable { viewModel.setOrderType("صالة") }
                                .testTag("order_type_dinein"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                width = if (isDineIn) 2.dp else 1.dp,
                                color = if (isDineIn) POSPrimary else POSBorder
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDineIn) POSPrimary.copy(alpha = 0.08f) else POSSurface
                            )
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Storefront,
                                        contentDescription = "صالة",
                                        tint = if (isDineIn) POSPrimary else TextMuted
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "صالة",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDineIn) POSPrimary else TextDark
                                    )
                                }
                            }
                        }

                        // Takeaway Option
                        val isTakeaway = orderType == "سفري"
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clickable { viewModel.setOrderType("سفري") }
                                .testTag("order_type_takeaway"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                width = if (isTakeaway) 2.dp else 1.dp,
                                color = if (isTakeaway) POSPrimary else POSBorder
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isTakeaway) POSPrimary.copy(alpha = 0.08f) else POSSurface
                            )
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.ShoppingBag,
                                        contentDescription = "سفري",
                                        tint = if (isTakeaway) POSPrimary else TextMuted
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "سفري",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isTakeaway) POSPrimary else TextDark
                                    )
                                }
                            }
                        }

                        // Delivery Option
                        val isDelivery = orderType == "دلفري"
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clickable { viewModel.setOrderType("دلفري") }
                                .testTag("order_type_delivery"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                width = if (isDelivery) 2.dp else 1.dp,
                                color = if (isDelivery) POSPrimary else POSBorder
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDelivery) POSPrimary.copy(alpha = 0.08f) else POSSurface
                            )
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.TwoWheeler,
                                        contentDescription = "دلفري",
                                        tint = if (isDelivery) POSPrimary else TextMuted
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "دلفري",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDelivery) POSPrimary else TextDark
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Optional/Mandatory Extra fields based on Order Type
                    if (orderType == "صالة") {
                        Text(
                            text = "رقم الطاولة (اختياري)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        OutlinedTextField(
                            value = orderTypeDetails,
                            onValueChange = { input ->
                                if (input.all { it.isDigit() }) {
                                    viewModel.setOrderTypeDetails(input)
                                }
                            },
                            placeholder = { Text("أدخل رقم الطاولة بالإنجليزية", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("table_number_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = POSPrimary,
                                unfocusedBorderColor = POSBorder
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    } else if (orderType == "دلفري") {
                        val isPhoneValid = orderTypeDetails.length == 11 && orderTypeDetails.all { it.isDigit() }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "رقم الهاتف للعميل (إلزامي - 11 رقم)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPhoneValid) POSSuccess else POSDanger,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            if (orderTypeDetails.isNotEmpty() && !isPhoneValid) {
                                Text(
                                    text = "يجب إدخال 11 رقماً",
                                    fontSize = 11.sp,
                                    color = POSDanger,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        OutlinedTextField(
                            value = orderTypeDetails,
                            onValueChange = { input ->
                                if (input.length <= 11 && input.all { it.isDigit() }) {
                                    viewModel.setOrderTypeDetails(input)
                                }
                            },
                            placeholder = { Text("مثال: 07810936407", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("delivery_phone_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = if (isPhoneValid) POSSuccess else POSDanger,
                                unfocusedBorderColor = POSBorder
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "عنوان الزبون",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        OutlinedTextField(
                            value = customerAddress,
                            onValueChange = { input ->
                                viewModel.setCustomerAddress(input)
                            },
                            placeholder = { Text("أدخل عنوان الزبون بالكامل", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("delivery_address_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = POSPrimary,
                                unfocusedBorderColor = POSBorder
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "سعر التوصيل",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        var isDropdownExpanded by remember { mutableStateOf(false) }

                        Box(modifier = Modifier.fillMaxWidth()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .clickable { isDropdownExpanded = true }
                                    .testTag("delivery_price_type_dropdown"),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, POSBorder),
                                colors = CardDefaults.cardColors(containerColor = POSSurface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val displayText = if (deliveryPriceType == "مجاني") "توصيل مجاني" else "قيمة التوصيل (مبلغ مخصص)"
                                    Text(text = displayText, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = POSPrimary
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = isDropdownExpanded,
                                onDismissRequest = { isDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.85f).background(POSSurface)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("توصيل مجاني (0 د.ع)", fontWeight = FontWeight.Bold, color = TextDark) },
                                    onClick = {
                                        viewModel.setDeliveryPriceType("مجاني")
                                        isDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("قيمة التوصيل (مبلغ مخصص يدوياً)", fontWeight = FontWeight.Bold, color = TextDark) },
                                    onClick = {
                                        viewModel.setDeliveryPriceType("قيمة التوصيل")
                                        isDropdownExpanded = false
                                    }
                                )
                            }
                        }

                        if (deliveryPriceType == "قيمة التوصيل") {
                            Spacer(modifier = Modifier.height(10.dp))
                            var feeInputText by remember { mutableStateOf(if (deliveryFee == 0.0) "" else deliveryFee.toInt().toString()) }

                            LaunchedEffect(deliveryFee) {
                                if (deliveryFee == 0.0) {
                                    feeInputText = ""
                                } else if (feeInputText.toDoubleOrNull() != deliveryFee) {
                                    feeInputText = deliveryFee.toInt().toString()
                                }
                            }

                            OutlinedTextField(
                                value = feeInputText,
                                onValueChange = { input ->
                                    val filteredInput = input.filter { it in '0'..'9' }
                                    feeInputText = filteredInput
                                    val feeVal = filteredInput.toDoubleOrNull() ?: 0.0
                                    viewModel.setDeliveryFee(feeVal)
                                },
                                placeholder = { Text("أدخل مبلغ التوصيل بالدينار العراقي", fontSize = 13.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("delivery_fee_input"),
                                label = { Text("قيمة التوصيل بالدينار العراقي") },
                                trailingIcon = { Text("د.ع", fontWeight = FontWeight.Bold, color = TextMuted) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = POSPrimary,
                                    unfocusedBorderColor = POSBorder
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (orderType == "دلفري") {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = POSPrimary.copy(alpha = 0.05f)),
                            border = BorderStroke(1.dp, POSPrimary.copy(alpha = 0.15f))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = POSPrimary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "طلب دلفري: يتم تحصيل كامل المبلغ (${formatIraqiDinar(totalAmount)}) مباشرة عند التسليم من قبل السائق وتسليمها للكاشير.",
                                    fontSize = 13.sp,
                                    color = TextDark,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    if (paymentMethod == "نقدي" && orderType != "دلفري") {
                        // Received Amount Input
                        Text(
                            text = "المبلغ المستلم من العميل",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = amountReceivedText,
                            onValueChange = { viewModel.updateAmountReceived(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("amount_received_input"),
                            placeholder = { Text("أدخل المبلغ المستلم د.ع") },
                            trailingIcon = { Text("د.ع", fontWeight = FontWeight.Bold, color = TextMuted) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    focusManager.clearFocus()
                                }
                            ),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = POSPrimary,
                                unfocusedBorderColor = POSBorder
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Suggested Quick Cash Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val suggestions = remember(totalAmount) {
                                val base = totalAmount.toInt()
                                val list = mutableListOf<Int>()
                                list.add(base)
                                if (base % 5000 != 0) {
                                    val next5k = ((base / 5000) + 1) * 5000
                                    list.add(next5k)
                                }
                                if (base % 10000 != 0) {
                                    val next10k = ((base / 10000) + 1) * 10000
                                    list.add(next10k)
                                }
                                if (base % 25000 != 0) {
                                    val next25k = ((base / 25000) + 1) * 25000
                                    if (!list.contains(next25k)) list.add(next25k)
                                }
                                val standard = listOf(5000, 10000, 25000, 50000, 100000)
                                for (valStd in standard) {
                                    if (valStd > base && !list.contains(valStd) && list.size < 4) {
                                        list.add(valStd)
                                    }
                                }
                                list.take(4)
                            }

                            suggestions.forEach { suggestion ->
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.updateAmountReceived(suggestion.toString()) },
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, POSBorder),
                                    colors = CardDefaults.cardColors(containerColor = LightGrayBg)
                                ) {
                                    Text(
                                        text = formatIraqiDinar(suggestion.toDouble()),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .padding(vertical = 10.dp)
                                            .fillMaxWidth(),
                                        color = TextDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Remaining / Change Card
                        val changeValid = amountReceived >= totalAmount
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (changeValid) POSSuccess.copy(alpha = 0.08f) else POSDanger.copy(alpha = 0.04f)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (changeValid) POSSuccess.copy(alpha = 0.3f) else POSDanger.copy(alpha = 0.2f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (changeValid) "المبلغ المتبقي للعميل (الخردة)" else "المبلغ المستلم غير كافٍ!",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (changeValid) POSSuccess else POSDanger
                                )
                                Text(
                                    text = if (changeValid) formatIraqiDinar(amountChange) else formatIraqiDinar(totalAmount - amountReceived),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (changeValid) POSSuccess else POSDanger
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Buttons (Dual Checkout Action Buttons)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isOrderTypeDetailsValid = when (orderType) {
                            "صالة" -> true
                            "سفري" -> true
                            "دلفري" -> orderTypeDetails.length == 11 && orderTypeDetails.all { it.isDigit() }
                            else -> true
                        }
                        val isDelivery = orderType == "دلفري"
                        val canSave = isPOSOpen && isOrderTypeDetailsValid && (isDelivery || (amountReceived >= totalAmount))

                        // Button 1: حفظ وطباعة الوصل
                        Button(
                            onClick = {
                                if (canSave) {
                                    scope.launch {
                                        isCheckingPrinters = true
                                        Toast.makeText(context, "جاري فحص اتصال الطابعات المحددة...", Toast.LENGTH_SHORT).show()
                                        
                                        // 1. Check main printer
                                        val mainOk = viewModel.checkPrinterConnection(mainPrinterMac)
                                        if (!mainOk) {
                                            isCheckingPrinters = false
                                            printerErrorToShow = mainPrinterName.ifBlank { "طابعة الكاشير" }
                                            return@launch
                                        }
                                        
                                        // 2. Check kitchen printer if enabled
                                        if (isKitchenPrinterEnabled) {
                                            val kitchenOk = viewModel.checkPrinterConnection(kitchenPrinterMac)
                                            if (!kitchenOk) {
                                                isCheckingPrinters = false
                                                printerErrorToShow = kitchenPrinterName.ifBlank { "طابعة المطبخ" }
                                                return@launch
                                            }
                                        }
                                        
                                        isCheckingPrinters = false
                                        // 3. Both printers are connected and working! Safely save the order
                                        val currentCart = cartItems.toList()
                                        viewModel.submitOrder { invoiceNo ->
                                            val activeShift = viewModel.shiftLogs.value.firstOrNull { it.status == "مفتوحة" }
                                            val currentShiftId = activeShift?.id ?: 0
                                            val invoice = Invoice(
                                                invoiceNumber = invoiceNo,
                                                orderTime = System.currentTimeMillis(),
                                                totalAmount = totalAmount,
                                                paymentMethod = paymentMethod,
                                                amountReceived = if (isDelivery) totalAmount else amountReceived,
                                                amountChange = if (isDelivery) 0.0 else amountChange,
                                                status = "مدفوعة",
                                                shiftId = currentShiftId,
                                                orderType = orderType,
                                                orderTypeDetails = orderTypeDetails,
                                                customerAddress = customerAddress
                                            )
                                            val items = currentCart.map { (product, qty) ->
                                                InvoiceItem(
                                                    invoiceNumber = invoiceNo,
                                                    productName = product.name,
                                                    productPrice = product.price,
                                                    productCost = 0.0,
                                                    quantity = qty
                                                )
                                            }
                                            // Immediately trigger Bluetooth printing
                                            ReceiptPrinterHelper.printReceipt(context, invoice, items)
                                            onPaymentSuccess(invoiceNo)
                                            onDismiss()
                                            Toast.makeText(context, "تم حفظ الطلب وإرساله للطباعة بنجاح", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else if (!isPOSOpen) {
                                    Toast.makeText(context, "الرجاء فتح وردية أولاً من الإعدادات لإتمام عملية المبيعات", Toast.LENGTH_LONG).show()
                                } else if (!isOrderTypeDetailsValid) {
                                    Toast.makeText(context, "الرجاء إدخال رقم هاتف صالح يتكون من 11 رقماً للطلب الدلفري", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "الرجاء إدخال مبلغ مستلم كافٍ أولاً", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = canSave && !isCheckingPrinters,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("save_and_print_order_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = POSPrimary,
                                contentColor = Color.White,
                                disabledContainerColor = POSBorder,
                                disabledContentColor = TextMuted
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Print, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("حفظ وطباعة الوصل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }

                        // Button 2: حفظ بدون طباعة الوصل
                        Button(
                            onClick = {
                                if (canSave) {
                                    viewModel.submitOrder { invoiceNo ->
                                        onPaymentSuccess(invoiceNo)
                                        onDismiss()
                                        Toast.makeText(context, "تم حفظ الطلب محلياً بنجاح (بدون طباعة)", Toast.LENGTH_SHORT).show()
                                    }
                                } else if (!isPOSOpen) {
                                    Toast.makeText(context, "الرجاء فتح وردية أولاً من الإعدادات لإتمام عملية المبيعات", Toast.LENGTH_LONG).show()
                                } else if (!isOrderTypeDetailsValid) {
                                    Toast.makeText(context, "الرجاء إدخال رقم هاتف صالح يتكون من 11 رقماً للطلب الدلفري", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "الرجاء إدخال مبلغ مستلم كافٍ أولاً", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = canSave,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("save_only_order_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF64748B), // Slate gray style for secondary save
                                contentColor = Color.White,
                                disabledContainerColor = POSBorder,
                                disabledContentColor = TextMuted
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("حفظ بدون طباعة الوصل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }

            if (printerErrorToShow != null) {
                AlertDialog(
                    onDismissRequest = { printerErrorToShow = null },
                    title = {
                        Text(
                            text = "تنبيه حالة الطابعة",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = POSPrimary
                        )
                    },
                    text = {
                        Text(
                            text = "تنبيه حالة الطابعة: ${printerErrorToShow} لا تعمل حالياً، يرجى التحقق من تشغيل الطابعة أو عودة الكهرباء لإتمام عملية البيع",
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = { printerErrorToShow = null }
                        ) {
                            Text(
                                text = "موافق",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = POSPrimary
                            )
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    containerColor = Color.White
                )
            }


        }
    }
}

@Composable
fun ReceiptPreviewDialog(
    invoice: Invoice,
    items: List<InvoiceItem>,
    onDismiss: () -> Unit,
    onPrintConfirmed: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.9f)
                    .padding(16.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = POSSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "معاينة الوصل قبل الطباعة",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = POSBorder)

                    // Paper Preview area showing the exact generated high-resolution bitmap
                    val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
                    val paperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
                    val generatedBitmap = remember {
                        com.example.utils.ReceiptPrinterHelper.generateCustomerReceiptBitmap(context, invoice, items, paperWidth)
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, POSBorder)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .background(Color.White)
                                .padding(16.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            androidx.compose.foundation.Image(
                                bitmap = generatedBitmap.asImageBitmap(),
                                contentDescription = "معاينة الفاتورة",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight(),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onPrintConfirmed,
                            modifier = Modifier.weight(1.5f).height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = POSAccent, contentColor = POSPrimary)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Print, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("طباعة الوصل الحقيقي", fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f).height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, POSBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextDark)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- Cart Sheet Component (عرض السلة الممتد) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartSheetContent(
    viewModel: POSViewModel,
    onClose: () -> Unit,
    onCheckoutClick: () -> Unit
) {
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalCount by viewModel.cartTotalCount.collectAsStateWithLifecycle()
    val totalAmount by viewModel.cartTotalAmount.collectAsStateWithLifecycle()

    val cartProducts by remember {
        derivedStateOf { cartItems.keys.toList() }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(POSSurface)
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = POSPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تفاصيل سلة الطلبات",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Badge(containerColor = POSPrimary) {
                        Text(text = "$totalCount", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(2.dp))
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق السلة")
                }
            }

            Divider(color = POSBorder, modifier = Modifier.padding(vertical = 12.dp))

            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.RemoveShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = TextMuted.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "السلة فارغة حالياً",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                        Text(
                            text = "اختر من المنتجات في الواجهة لإضافتها هنا",
                            fontSize = 13.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                // Cart Items List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cartProducts, key = { it.id }) { product ->
                        val qty = cartItems[product] ?: 0
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("cart_item_${product.id}"),
                            colors = CardDefaults.cardColors(containerColor = POSSurface),
                            border = BorderStroke(1.dp, POSBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Product Image Thumbnail
                                Image(
                                    painter = getProductImagePainter(product.imageResName),
                                    contentDescription = product.name,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                // Product Name & Total Price
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = product.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = formatIraqiDinar(product.price * qty),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = POSAccent,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }

                                // Quantity Controls
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // Minus
                                    IconButton(
                                        onClick = { viewModel.decreaseProductQty(product) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(LightGrayBg, CircleShape)
                                            .testTag("cart_minus_${product.id}")
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "تقليل", modifier = Modifier.size(16.dp), tint = POSPrimary)
                                    }

                                    Text(
                                        text = "$qty",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp),
                                        color = TextDark
                                    )

                                    // Plus
                                    IconButton(
                                        onClick = { viewModel.addProductToCart(product) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(LightGrayBg, CircleShape)
                                            .testTag("cart_plus_${product.id}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "زيادة", modifier = Modifier.size(16.dp), tint = POSPrimary)
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // Trash Icon
                                    IconButton(
                                        onClick = { viewModel.removeProductFromCart(product) },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("cart_delete_${product.id}")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = POSDanger)
                                    }
                                }
                            }
                        }
                    }
                }

                Divider(color = POSBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Footer Area
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "الإجمالي الكلي للسلة", fontSize = 13.sp, color = TextMuted)
                        Text(
                            text = formatIraqiDinar(totalAmount),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = POSPrimary
                        )
                    }

                    Button(
                        onClick = onCheckoutClick,
                        modifier = Modifier
                            .height(50.dp)
                            .width(180.dp)
                            .testTag("cart_sheet_checkout"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = POSPrimary, contentColor = Color.White)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إرسال للدفع", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- Dialog: CRUD Section/Category Add & Edit (إدارة الأقسام) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCategoryDialog(
    category: Category? = null, // Null means Add Mode
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var categoryName by remember { mutableStateOf(category?.name ?: "") }
    val focusManager = LocalFocusManager.current

    Dialog(onDismissRequest = onDismiss) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = POSSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = if (category == null) "إضافة قسم جديد" else "تعديل قسم: ${category.name}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = categoryName,
                        onValueChange = { categoryName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("category_name_input"),
                        label = { Text("اسم القسم") },
                        placeholder = { Text("مثال: بركر، حلويات، كافيه") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (categoryName.isNotBlank()) {
                                    onSave(categoryName)
                                    focusManager.clearFocus()
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = POSPrimary,
                            unfocusedBorderColor = POSBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إلغاء", color = TextMuted)
                        }

                        Button(
                            onClick = {
                                if (categoryName.isNotBlank()) {
                                    onSave(categoryName)
                                }
                            },
                            enabled = categoryName.isNotBlank(),
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("save_category_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = POSPrimary)
                        ) {
                            Text("حفظ القسم", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- Dialog: CRUD Product Add & Edit (إدارة المنتجات) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    product: Product? = null, // Null means Add Mode
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (name: String, catId: Int, price: Double, imgRes: String) -> Unit,
    defaultCategoryId: Int? = null
) {
    var productName by remember { mutableStateOf(product?.name ?: "") }
    var productPrice by remember { mutableStateOf(product?.price?.toInt()?.toString() ?: "") }
    var selectedCategoryId by remember { mutableStateOf(product?.categoryId ?: (defaultCategoryId ?: (categories.firstOrNull()?.id ?: 0))) }
    val focusManager = LocalFocusManager.current

    var selectedImageRes by remember { mutableStateOf(product?.imageResName ?: "") }

    val context = androidx.compose.ui.platform.LocalContext.current
    val galleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore if not persistable or already granted
            }
            selectedImageRes = uri.toString()
        }
    }

    var expandedDropdown by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = POSSurface),
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .wrapContentHeight()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = if (product == null) "إضافة منتج جديد" else "تعديل المنتج: ${product.name}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Name Input
                    OutlinedTextField(
                        value = productName,
                        onValueChange = { productName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("product_name_input"),
                        label = { Text("اسم المنتج") },
                        placeholder = { Text("مثال: شاورما لحم سوبر") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = POSPrimary,
                            unfocusedBorderColor = POSBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Price Input
                    OutlinedTextField(
                        value = productPrice,
                        onValueChange = {
                            if (it.isEmpty() || it.all { char -> char.isDigit() }) {
                                productPrice = it
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("product_price_input"),
                        label = { Text("سعر البيع بالدينار العراقي") },
                        placeholder = { Text("مثال: 9500") },
                        trailingIcon = { Text("د.ع", fontWeight = FontWeight.Bold, color = TextMuted) },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                            }
                        ),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = POSPrimary,
                            unfocusedBorderColor = POSBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Category Selection Dropdown
                    Text("القسم التابع له", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = POSPrimary, modifier = Modifier.padding(bottom = 6.dp))
                    Box(modifier = Modifier.fillMaxWidth()) {
                        val currentCatName = categories.find { it.id == selectedCategoryId }?.name ?: "اختر قسم..."
                        OutlinedCard(
                            onClick = { expandedDropdown = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, POSBorder),
                            colors = CardDefaults.outlinedCardColors(containerColor = POSSurface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = currentCatName, color = TextDark, fontSize = 15.sp)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = POSPrimary)
                            }
                        }

                        DropdownMenu(
                            expanded = expandedDropdown,
                            onDismissRequest = { expandedDropdown = false },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .background(POSSurface)
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name, fontSize = 15.sp, color = TextDark) },
                                    onClick = {
                                        selectedCategoryId = cat.id
                                        expandedDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Image Selector
                    Text("صورة المنتج التعبيرية", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = POSPrimary)
                    Spacer(modifier = Modifier.height(8.dp))

                    val isCustomImage = selectedImageRes.startsWith("content://") || selectedImageRes.startsWith("file://")
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedCard(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(56.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isCustomImage) POSPrimary else POSBorder),
                            colors = CardDefaults.outlinedCardColors(
                                containerColor = if (isCustomImage) POSPrimary.copy(alpha = 0.05f) else POSSurface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = androidx.compose.material.icons.Icons.Default.PhotoLibrary,
                                    contentDescription = null,
                                    tint = if (isCustomImage) POSPrimary else TextMuted
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                text = if (isCustomImage) "تغيير صورة المعرض" else "اختيار صورة من المعرض",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCustomImage) POSPrimary else TextDark
                                )
                            }
                        }
                        
                        if (isCustomImage) {
                            Card(
                                modifier = Modifier
                                    .size(56.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(2.dp, POSPrimary)
                            ) {
                                Image(
                                    painter = getProductImagePainter(selectedImageRes),
                                    contentDescription = "صورة مخصصة",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إلغاء", color = TextMuted)
                        }

                        Button(
                            onClick = {
                                val priceVal = productPrice.toDoubleOrNull() ?: 0.0
                                if (productName.isNotBlank() && priceVal > 0 && selectedCategoryId != 0) {
                                    onSave(productName, selectedCategoryId, priceVal, selectedImageRes)
                                }
                            },
                            enabled = productName.isNotBlank() && (productPrice.toDoubleOrNull() ?: 0.0) > 0,
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("save_product_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = POSPrimary)
                        ) {
                            Text("حفظ المنتج", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


