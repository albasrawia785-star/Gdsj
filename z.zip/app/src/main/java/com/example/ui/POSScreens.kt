package com.example.ui

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.utils.ReceiptPrinterHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.text.input.KeyboardType
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.window.DialogProperties

// ==========================================
// 1. HOME CASHIER SCREEN (واجهة الكاشير)
// ==========================================
@Composable
fun HomeScreen(viewModel: POSViewModel) {
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val filteredProducts by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val selectedCategoryId by viewModel.selectedCategoryId.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // Cart summary states
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalCount by viewModel.cartTotalCount.collectAsStateWithLifecycle()
    val totalAmount by viewModel.cartTotalAmount.collectAsStateWithLifecycle()
    val restaurantName by viewModel.restaurantName.collectAsStateWithLifecycle()

    val activeCategoryId by remember {
        derivedStateOf { selectedCategoryId ?: categories.firstOrNull()?.id }
    }

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(POSBackground)
        ) {
            // Top Header Section (Royal Navy Premium Block)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = POSPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                border = null
            ) {
                Column(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                        .fillMaxWidth()
                ) {
                    // Header details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(Color.White.copy(alpha = 0.1f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Restaurant,
                                    contentDescription = null,
                                    tint = POSAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = restaurantName.ifBlank { "مطعم ومقهى النخبة" },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "نظام كاشير POS محترف",
                                    fontSize = 11.sp,
                                    color = TextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Action buttons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
                            
                            // User tag badge
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = activeUser,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = POSAccent
                                )
                            }
                            
                            // Logout button
                            IconButton(
                                onClick = { viewModel.logout() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Logout, 
                                    contentDescription = "تسجيل الخروج", 
                                    tint = POSDanger,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Big Search Bar (Glassmorphic Styled)
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("pos_search_bar"),
                        placeholder = { Text("البحث عن وجبة أو مشروب...", fontSize = 14.sp, color = TextMuted, fontWeight = FontWeight.Medium) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح", tint = Color.White)
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                            }
                        ),
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White.copy(alpha = 0.12f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.06f),
                            focusedBorderColor = POSAccent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            }

            // Horizontal Category Tabs
            Spacer(modifier = Modifier.height(14.dp))
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories, key = { it.id }) { category ->
                    val isSelected = activeCategoryId == category.id
                    CategoryTab(
                        name = category.name,
                        isSelected = isSelected,
                        onClick = { viewModel.selectCategory(category.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Product Grid list (2-columns)
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.SearchOff,
                            contentDescription = null,
                            modifier = Modifier.size(54.dp),
                            tint = TextMuted.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "عذراً، لم نجد أي منتجات تطابق البحث",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductGridCard(
                            product = product,
                            onAddClick = {
                                viewModel.addProductToCart(product)
                                Toast.makeText(context, "تمت الإضافة: ${product.name}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // Persistent bottom cart bar (Editorial Aesthetic Styled)
            if (totalCount > 0) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .clickable { viewModel.setShowCartSheet(true) }
                        .shadow(elevation = 8.dp, shape = RoundedCornerShape(20.dp))
                        .testTag("persistent_cart_bar"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(POSPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$totalCount",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "إجمالي السلة", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                                Text(text = formatIraqiDinar(totalAmount), fontSize = 16.sp, fontWeight = FontWeight.Black, color = POSPrimary)
                            }
                        }

                        // Elegant CTA button on right
                        Surface(
                            color = POSPrimary,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(horizontal = 16.dp)
                                    .fillMaxHeight(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(text = "عرض السلة ودفع", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = POSAccent, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun CategoryTab(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag("category_tab_$name"),
        shape = RoundedCornerShape(20.dp),
        border = if (isSelected) null else BorderStroke(1.dp, POSBorder),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) POSPrimary else Color.White
        )
    ) {
        Text(
            text = name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = if (isSelected) Color.White else POSPrimary,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun ProductGridCard(
    product: Product,
    onAddClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp))
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Large Product Image
            if (product.imageResName.isNotBlank() && product.imageResName != "null") {
                Image(
                    painter = getProductImagePainter(product.imageResName),
                    contentDescription = product.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            // Content
            Column(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = product.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = POSPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatIraqiDinar(product.price),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )

                    // Circular Plus Button
                    IconButton(
                        onClick = onAddClick,
                        modifier = Modifier
                            .size(30.dp)
                            .background(POSAccent, CircleShape)
                            .testTag("add_to_cart_btn_${product.id}")
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "إضافة للسلة",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// 2. ORDERS SCREEN (واجهة الطلبات)
// ==========================================
@Composable
fun OrdersScreen(viewModel: POSViewModel) {
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val allInvoiceItems by viewModel.allInvoiceItems.collectAsStateWithLifecycle()
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val invoiceLimit by viewModel.invoiceLimit.collectAsStateWithLifecycle()
    val isDemo = false
    val context = LocalContext.current

    var invoiceToDelete by remember { mutableStateOf<Invoice?>(null) }
    var cancelReasonText by remember { mutableStateOf("") }
    val quickReasons = listOf("خطأ في تسجيل الطلب", "إلغاء بطلب من الزبون", "تعديل وتغيير المواد", "أخرى")

    if (invoiceToDelete != null) {
        AlertDialog(
            onDismissRequest = { 
                invoiceToDelete = null 
                cancelReasonText = ""
            },
            title = { Text("تأكيد إلغاء الطلب", fontWeight = FontWeight.Black, color = Color.Black) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "يرجى تحديد أو إدخال سبب إلغاء الفاتورة رقم #${invoiceToDelete!!.invoiceNumber}:",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        quickReasons.forEach { reason ->
                            Card(
                                onClick = { cancelReasonText = reason },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (cancelReasonText == reason) POSPrimary else POSBorder
                                ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (cancelReasonText == reason) POSPrimary.copy(alpha = 0.08f) else Color.White
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = (cancelReasonText == reason),
                                        onClick = { cancelReasonText = reason },
                                        colors = RadioButtonDefaults.colors(selectedColor = POSPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = reason, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = cancelReasonText,
                        onValueChange = { cancelReasonText = it },
                        placeholder = { Text("اكتب سبب الإلغاء بالتفصيل...", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black,
                            focusedBorderColor = POSPrimary,
                            unfocusedBorderColor = POSBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = cancelReasonText.trim()
                        if (isDemo) {
                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                        } else if (reason.isEmpty()) {
                            Toast.makeText(context, "الرجاء إدخال أو اختيار سبب الإلغاء", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.cancelInvoice(invoiceToDelete!!, reason)
                            Toast.makeText(context, "تم إلغاء الطلب بنجاح", Toast.LENGTH_SHORT).show()
                            invoiceToDelete = null
                            cancelReasonText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("تأكيد إلغاء الطلب", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    invoiceToDelete = null
                    cancelReasonText = ""
                }) {
                    Text("تراجع", fontWeight = FontWeight.Bold, color = TextMuted)
                }
            },
            containerColor = Color.White
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(POSBackground)
        ) {
            // Royal Navy Header Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(POSPrimary)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "سجل الطلبات والمبيعات",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الفواتير المسجلة في نقطة البيع الحالية والسابقة",
                            fontSize = 13.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Rounded icon box
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = POSAccent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (invoices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .background(Color.White, CircleShape)
                                .shadow(1.dp, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = null,
                                modifier = Modifier.size(46.dp),
                                tint = TextMuted
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "لا توجد فواتير مسجلة بعد",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = POSPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "عند إتمام أي طلب بيع، ستظهر تفاصيل الفاتورة هنا.",
                            fontSize = 14.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(invoices, key = { it.invoiceNumber }) { invoice ->
                        InvoiceHistoryCard(
                            invoice = invoice,
                            onPrintClick = {
                                val items = allInvoiceItems.filter { it.invoiceNumber == invoice.invoiceNumber }
                                ReceiptPrinterHelper.printReceipt(context, invoice, items)
                            },
                            onDeleteClick = {
                                invoiceToDelete = invoice
                            }
                        )
                    }

                    item {
                        if (invoices.size >= invoiceLimit) {
                            Button(
                                onClick = { viewModel.loadMoreInvoices() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تحميل المزيد من الفواتير القديمة", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InvoiceHistoryCard(
    invoice: Invoice,
    onPrintClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateStr = remember(invoice.orderTime) {
        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))
        sdf.format(Date(invoice.orderTime))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp))
            .testTag("invoice_card_${invoice.invoiceNumber}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        val isCancelled = invoice.status == "ملغاة"
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "فاتورة مبيعات ",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary
                    )
                    Text(
                        text = "#${invoice.invoiceNumber}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )
                }

                // Payment Status Badge
                val badgeBg = if (isCancelled) POSDanger.copy(alpha = 0.1f) else POSSuccess.copy(alpha = 0.1f)
                val badgeTextColor = if (isCancelled) POSDanger else POSSuccess
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = badgeBg
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Text(
                        text = "${invoice.status} (${invoice.orderType})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = badgeTextColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "تاريخ الطلب", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(text = dateStr, fontSize = 13.sp, color = POSPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "طريقة الدفع", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        Icon(
                            imageVector = if (invoice.paymentMethod == "نقدي") Icons.Default.Payments else Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = POSAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = invoice.paymentMethod, fontSize = 13.sp, color = POSPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Divider(
                color = LightGrayBg, 
                modifier = Modifier.padding(vertical = 14.dp)
            )

            // Pricing and Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "إجمالي الفاتورة", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Text(
                        text = formatIraqiDinar(invoice.totalAmount),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFFEF2F2), CircleShape)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف الفاتورة", tint = POSDanger, modifier = Modifier.size(18.dp))
                    }

                    OutlinedButton(
                        onClick = onPrintClick,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.5.dp, POSPrimary),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = POSPrimary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إعادة طباعة", fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            if (isCancelled) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = POSDanger.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, POSDanger.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = POSDanger,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "سبب الإلغاء: ${invoice.cancelReason ?: "غير محدد"}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSDanger
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// 3. MENU SCREEN (واجهة المنيو)
// ==========================================
@Composable
fun MenuScreen(viewModel: POSViewModel, onBack: (() -> Unit)? = null) {
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val isDemo = false

    var showAddCategory by remember { mutableStateOf(false) }
    var showAddProduct by remember { mutableStateOf(false) }

    var editingCategory by remember { mutableStateOf<Category?>(null) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }

    // State for expanded categories
    var expandedCategories by remember { mutableStateOf(setOf<Int>()) }
    
    // State for pre-selected category ID when adding a meal
    var preSelectedCategoryId by remember { mutableStateOf<Int?>(null) }

    val context = LocalContext.current

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(POSBackground)
        ) {
            // Royal Navy Header Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(POSPrimary)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (onBack != null) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = Color.White
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "إدارة قائمة الطعام",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "إضافة وتعديل الأقسام والوجبات",
                                fontSize = 13.sp,
                                color = TextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Fork & Knife Icon inside a circular background
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestaurantMenu,
                            contentDescription = null,
                            tint = POSAccent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Adding Buttons Row (RTL)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // "إضافة وجبة جديدة" Button (Left in RTL layout visually)
                Card(
                    modifier = Modifier
                        .weight(1.3f)
                        .height(54.dp)
                        .clickable {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                if (categories.isEmpty()) {
                                    Toast.makeText(context, "يجب إضافة قسم واحد على الأقل أولاً!", Toast.LENGTH_LONG).show()
                                } else {
                                    showAddProduct = true
                                }
                            }
                        }
                        .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp))
                        .testTag("add_product_quick_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSAccent),
                    border = null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color.Black, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = POSAccent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إضافة وجبة جديدة",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }

                // "إضافة قسم جديد" Button
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .clickable {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                showAddCategory = true
                            }
                        }
                        .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp))
                        .testTag("add_category_quick_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSPrimary),
                    border = null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Category,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إضافة قسم جديد",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Categories List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (categories.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp)
                                .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .background(Color(0xFFFEF3C7), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RestaurantMenu,
                                        contentDescription = null,
                                        tint = POSWarning,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "قائمة الطعام فارغة بالكامل",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = POSPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "تم تصفير النظام وإعادة تهيئته بناءً على رغبتك. للبدء:",
                                    fontSize = 13.sp,
                                    color = TextMuted,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    lineHeight = 20.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "1. اضغط على زر \"إضافة قسم جديد\" باللون الكحلي لإنشاء الأقسام (مثل: مشويات، بيتزا).",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF334155)
                                        )
                                        Text(
                                            text = "2. اضغط على زر \"إضافة وجبة جديدة\" باللون البرتقالي لإدخال الوجبات وأسعارها وربطها بالقسم.",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF334155)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(categories, key = { it.id }) { category ->
                        val isExpanded = expandedCategories.contains(category.id)
                        val categoryProducts by remember(allProducts, category.id) {
                            derivedStateOf { allProducts.filter { it.categoryId == category.id } }
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = null
                    ) {
                        Column {
                            // Category Header Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        expandedCategories = if (isExpanded) {
                                            expandedCategories - category.id
                                        } else {
                                            expandedCategories + category.id
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Right Side of Row: Chevron, Name, and Count Badge
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = TextMuted,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = category.name,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.Black
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    // Badge for item count
                                    Box(
                                        modifier = Modifier
                                            .background(LightGrayBg, RoundedCornerShape(20.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${categoryProducts.size}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextMuted
                                        )
                                    }
                                }

                                // Left Side of Row: 6-dot drag handle & Edit/Delete menu
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Options Dropdown Menu for Category
                                    Box {
                                        var showCatMenu by remember { mutableStateOf(false) }
                                        IconButton(
                                            onClick = { showCatMenu = true },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MoreVert,
                                                contentDescription = "خيارات القسم",
                                                tint = TextMuted
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = showCatMenu,
                                            onDismissRequest = { showCatMenu = false },
                                            modifier = Modifier
                                                .background(Color.White)
                                                .border(1.dp, POSBorder, RoundedCornerShape(20.dp))
                                        ) {
                                            DropdownMenuItem(
                                                text = {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(
                                                            imageVector = Icons.Default.Edit,
                                                            contentDescription = null,
                                                            tint = Color.Black,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text("تعديل القسم", fontWeight = FontWeight.Bold)
                                                    }
                                                },
                                                onClick = {
                                                    showCatMenu = false
                                                    if (isDemo) {
                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        editingCategory = category
                                                    }
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(
                                                            imageVector = Icons.Default.Delete,
                                                            contentDescription = null,
                                                            tint = POSDanger,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text("حذف القسم", color = POSDanger, fontWeight = FontWeight.Bold)
                                                    }
                                                },
                                                onClick = {
                                                    showCatMenu = false
                                                    if (isDemo) {
                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        viewModel.deleteCategory(category)
                                                        Toast.makeText(context, "تم حذف القسم: ${category.name}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            )
                                        }
                                    }

                                    // Beautiful 6-dot drag handle
                                    Column(
                                        modifier = Modifier.width(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        repeat(3) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                repeat(2) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(3.dp)
                                                            .background(POSBorder, CircleShape)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Products inside Category (Animated expansion)
                            AnimatedVisibility(
                                visible = isExpanded,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                Column {
                                    Divider(color = LightGrayBg, thickness = 1.dp)

                                    if (categoryProducts.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 24.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "لا توجد وجبات في هذا القسم حتى الآن.",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Gray
                                            )
                                        }
                                    } else {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            categoryProducts.forEach { product ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color.White)
                                                        .padding(horizontal = 4.dp, vertical = 6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    // Options Dropdown Menu for Product (Far Left)
                                                    Box {
                                                        var showProdMenu by remember { mutableStateOf(false) }
                                                        IconButton(
                                                            onClick = { showProdMenu = true },
                                                            modifier = Modifier.size(36.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.MoreVert,
                                                                contentDescription = "خيارات الوجبة",
                                                                tint = TextMuted
                                                            )
                                                        }

                                                        DropdownMenu(
                                                            expanded = showProdMenu,
                                                            onDismissRequest = { showProdMenu = false },
                                                            modifier = Modifier
                                                                .background(Color.White)
                                                                .border(1.dp, POSBorder, RoundedCornerShape(20.dp))
                                                        ) {
                                                            DropdownMenuItem(
                                                                text = {
                                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.Edit,
                                                                            contentDescription = null,
                                                                            tint = Color.Black,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Spacer(modifier = Modifier.width(8.dp))
                                                                        Text("تعديل الوجبة", fontWeight = FontWeight.Bold)
                                                                    }
                                                                },
                                                                onClick = {
                                                                    showProdMenu = false
                                                                    if (isDemo) {
                                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                                    } else {
                                                                        editingProduct = product
                                                                    }
                                                                }
                                                            )
                                                            DropdownMenuItem(
                                                                text = {
                                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.Delete,
                                                                            contentDescription = null,
                                                                            tint = POSDanger,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Spacer(modifier = Modifier.width(8.dp))
                                                                        Text("حذف الوجبة", color = POSDanger, fontWeight = FontWeight.Bold)
                                                                    }
                                                                },
                                                                onClick = {
                                                                    showProdMenu = false
                                                                    if (isDemo) {
                                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                                    } else {
                                                                        viewModel.deleteProduct(product)
                                                                        Toast.makeText(context, "تم حذف الوجبة: ${product.name}", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                }
                                                            )
                                                        }
                                                    }

                                                    // Text Info (Middle, Aligned Right)
                                                    Column(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .padding(horizontal = 16.dp),
                                                        horizontalAlignment = Alignment.Start // Start in RTL row nested is RTL right-aligned visually
                                                    ) {
                                                        Text(
                                                            text = product.name,
                                                            fontSize = 16.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color.Black
                                                        )
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Text(
                                                            text = formatIraqiDinar(product.price),
                                                            fontSize = 14.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = TextMuted
                                                        )
                                                    }

                                                    // Product Image on the Far Right
                                                    if (product.imageResName.isNotBlank() && product.imageResName != "null") {
                                                        Image(
                                                            painter = getProductImagePainter(product.imageResName),
                                                            contentDescription = product.name,
                                                            modifier = Modifier
                                                                .size(64.dp)
                                                                .clip(RoundedCornerShape(20.dp))
                                                                .background(LightGrayBg),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                    }
                                                }
                                                
                                                Divider(color = LightGrayBg, thickness = 0.5.dp, modifier = Modifier.padding(horizontal = 8.dp))
                                            }
                                        }
                                    }

                                    // Add Product directly into this category button
                                    OutlinedButton(
                                        onClick = {
                                            if (isDemo) {
                                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                            } else {
                                                preSelectedCategoryId = category.id
                                                showAddProduct = true
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        border = BorderStroke(1.dp, POSBorder),
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = POSPrimary)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "إضافة وجبة داخل هذا القسم",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

        // Add Category Dialog
        if (showAddCategory) {
            AddEditCategoryDialog(
                category = null,
                onDismiss = { showAddCategory = false },
                onSave = { name ->
                    viewModel.addCategory(name)
                    showAddCategory = false
                    Toast.makeText(context, "تمت إضافة القسم: $name", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Edit Category Dialog
        if (editingCategory != null) {
            AddEditCategoryDialog(
                category = editingCategory,
                onDismiss = { editingCategory = null },
                onSave = { name ->
                    editingCategory?.let { cat ->
                        viewModel.editCategory(cat.copy(name = name))
                    }
                    editingCategory = null
                    Toast.makeText(context, "تم تعديل القسم بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Add Product Dialog
        if (showAddProduct) {
            AddEditProductDialog(
                product = null,
                categories = categories,
                onDismiss = { 
                    showAddProduct = false
                    preSelectedCategoryId = null
                },
                onSave = { name, catId, price, imgRes ->
                    viewModel.addProduct(name, catId, price, imgRes)
                    showAddProduct = false
                    preSelectedCategoryId = null
                    Toast.makeText(context, "تمت إضافة المنتج بنجاح", Toast.LENGTH_SHORT).show()
                },
                defaultCategoryId = preSelectedCategoryId
            )
        }

        // Edit Product Dialog
        if (editingProduct != null) {
            AddEditProductDialog(
                product = editingProduct,
                categories = categories,
                onDismiss = { editingProduct = null },
                onSave = { name, catId, price, imgRes ->
                    editingProduct?.let { prod ->
                        viewModel.editProduct(prod.copy(name = name, categoryId = catId, price = price, imageResName = imgRes))
                    }
                    editingProduct = null
                    Toast.makeText(context, "تم تعديل المنتج بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}


// ==========================================
// 4. SETTINGS SCREEN (واجهة الإعدادات)
// ==========================================
@Composable
fun SuperAdminClientManagementCard(
    viewModel: POSViewModel,
    clientAccounts: List<com.example.utils.UserAccount>
) {
    var isExpanded by remember { mutableStateOf(true) }
    var newUsername by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var newRestaurantName by remember { mutableStateOf("") }
    var newPhoneNumber by remember { mutableStateOf("") }
    var selectedLicenseType by remember { mutableStateOf("PERMANENT") }
    var selectedTrialDays by remember { mutableStateOf(30) }
    var isSubmitting by remember { mutableStateOf(false) }
    var accountToDelete by remember { mutableStateOf<com.example.utils.UserAccount?>(null) }

    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 2.dp, shape = RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.5.dp, POSPrimary)
    ) {
        Column {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .background(POSPrimary.copy(alpha = 0.05f))
                    .padding(18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(POSPrimary, RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SupervisorAccount,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "قسم إدارة وتفعيل العملاء (Super Admin)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = POSPrimary
                        )
                        Text(
                            text = "إضافة وتفعيل مشتركي النظام في سيرفر الفايربيس",
                            fontSize = 12.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = POSPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            if (isExpanded) {
                Divider(color = POSBorder, thickness = 1.dp)

                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "إضافة عميل / مطعم جديد",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = newUsername,
                            onValueChange = { newUsername = it },
                            label = { Text("اسم المستخدم", fontSize = 12.sp) },
                            placeholder = { Text("مطعم_الخير") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it },
                            label = { Text("كلمة المرور", fontSize = 12.sp) },
                            placeholder = { Text("كلمة المرور") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = newRestaurantName,
                            onValueChange = { newRestaurantName = it },
                            label = { Text("اسم المطعم / الكافيه", fontSize = 12.sp) },
                            placeholder = { Text("مطعم النخبة") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = newPhoneNumber,
                            onValueChange = { newPhoneNumber = it },
                            label = { Text("رقم الهاتف", fontSize = 12.sp) },
                            placeholder = { Text("07701234567") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("نوع الاشتراك والتفعيل", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = selectedLicenseType == "PERMANENT",
                            onClick = { selectedLicenseType = "PERMANENT" },
                            label = { Text("دائمي (PERMANENT)", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedLicenseType == "TRIAL",
                            onClick = { selectedLicenseType = "TRIAL" },
                            label = { Text("تجريبي (TRIAL)", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (selectedLicenseType == "TRIAL") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("حدد عدد الأيام التجريبية:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(7, 14, 30, 60, 90).forEach { days ->
                                val isDaysSelected = selectedTrialDays == days
                                OutlinedButton(
                                    onClick = { selectedTrialDays = days },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isDaysSelected) POSPrimary else Color.Transparent,
                                        contentColor = if (isDaysSelected) Color.White else POSPrimary
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(2.dp)
                                ) {
                                    Text("$days يوم", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (newUsername.isBlank() || newPassword.isBlank() || newRestaurantName.isBlank()) {
                                Toast.makeText(context, "يرجى تعبئة الحقول الأساسية (اسم المستخدم، كلمة المرور، اسم المطعم)", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isSubmitting = true
                            viewModel.registerNewClient(
                                username = newUsername.trim(),
                                pass = newPassword.trim(),
                                restaurantName = newRestaurantName.trim(),
                                phoneNumber = newPhoneNumber.trim(),
                                licenseType = selectedLicenseType,
                                trialDays = if (selectedLicenseType == "TRIAL") selectedTrialDays else -1,
                                onComplete = { success, msg ->
                                    isSubmitting = false
                                    Toast.makeText(context, msg ?: if (success) "تم التفعيل بنجاح" else "حدث خطأ", Toast.LENGTH_LONG).show()
                                    if (success) {
                                        newUsername = ""
                                        newPassword = ""
                                        newRestaurantName = ""
                                        newPhoneNumber = ""
                                    }
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = POSSuccess)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("رفع بيانات العميل والتفعيل في Firebase", fontWeight = FontWeight.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = POSBorder, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "قائمة المشتركين المسجلين (${clientAccounts.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (clientAccounts.isEmpty()) {
                        Text(
                            text = "لا يوجد عملاء مسجلون حالياً في المسار licenses.",
                            fontSize = 13.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        clientAccounts.forEach { acc ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = POSBackground),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, POSBorder)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = acc.restaurantName.ifBlank { acc.username },
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Black,
                                                color = Color.Black
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        if (acc.isActive) POSSuccess.copy(alpha = 0.15f) else POSDanger.copy(alpha = 0.15f),
                                                        RoundedCornerShape(6.dp)
                                                    )
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = if (acc.isActive) "نشط" else "معطل",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (acc.isActive) POSSuccess else POSDanger
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "المستخدم: ${acc.username} | كلمة المرور: ${acc.password}",
                                            fontSize = 11.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "الهاتف: ${acc.phoneNumber.ifBlank { "غير محدد" }} | نوع الاشتراك: ${if (acc.type == "TRIAL") "تجريبي" else "دائمي"}",
                                            fontSize = 11.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.toggleClientAccountStatus(acc.keyId, acc.isActive) { success ->
                                                    val statusStr = if (!acc.isActive) "تفعيل" else "تعطيل"
                                                    Toast.makeText(context, if (success) "تم $statusStr الحساب" else "فشل العملية", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (acc.isActive) POSDanger else POSSuccess
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (acc.isActive) "تعطيل" else "تفعيل",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                accountToDelete = acc
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = POSDanger
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف المشترك",
                                                tint = Color.White,
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = "حذف",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (accountToDelete != null) {
        AlertDialog(
            onDismissRequest = { accountToDelete = null },
            title = {
                Text(
                    text = "تأكيد حذف المشترك",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف حساب المشترك (${accountToDelete?.restaurantName?.ifBlank { accountToDelete?.username }}) بشكل نهائي من قاعدة البيانات؟ لا يمكن التراجع عن هذا الإجراء.",
                    fontSize = 14.sp,
                    color = Color.DarkGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = accountToDelete
                        if (target != null) {
                            viewModel.deleteClientAccount(target.keyId) { success ->
                                Toast.makeText(
                                    context,
                                    if (success) "تم حذف حساب المشترك نهائياً" else "فشل حذف الحساب",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        accountToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حذف نهائي", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { accountToDelete = null }) {
                    Text("إلغاء", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@SuppressLint("MissingPermission")
@Composable
fun SettingsScreen(viewModel: POSViewModel) {
    val isPOSOpen by viewModel.isPOSOpen.collectAsStateWithLifecycle()
    val printerName by viewModel.printerName.collectAsStateWithLifecycle()
    val shiftLogs by viewModel.shiftLogs.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val allInvoiceItems by viewModel.allInvoiceItems.collectAsStateWithLifecycle()
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val isSuperAdmin by viewModel.isSuperAdmin.collectAsStateWithLifecycle()
    val clientAccounts by viewModel.clientAccounts.collectAsStateWithLifecycle()
    val isDemo = false

    LaunchedEffect(isSuperAdmin, activeUser) {
        if (isSuperAdmin || activeUser == "ali") {
            viewModel.fetchAllClientAccounts()
        }
    }

    val textThickness by viewModel.textThickness.collectAsStateWithLifecycle()
    val logoPrintSize by viewModel.logoPrintSize.collectAsStateWithLifecycle()
    val restaurantLogoPath by viewModel.restaurantLogoPath.collectAsStateWithLifecycle()

    val mainPrinterStatus by viewModel.mainPrinterStatus.collectAsStateWithLifecycle()
    val kitchenPrinterStatus by viewModel.kitchenPrinterStatus.collectAsStateWithLifecycle()
    val isScanningMainPrinter by viewModel.isScanningMainPrinter.collectAsStateWithLifecycle()
    val isScanningKitchenPrinter by viewModel.isScanningKitchenPrinter.collectAsStateWithLifecycle()
    val discoveredMainPrinters by viewModel.discoveredMainPrinters.collectAsStateWithLifecycle()
    val discoveredKitchenPrinters by viewModel.discoveredKitchenPrinters.collectAsStateWithLifecycle()
    val selectedKitchenPrinterName by viewModel.selectedKitchenPrinterName.collectAsStateWithLifecycle()

    var showOpenShiftDialog by remember { mutableStateOf(false) }
    var shiftNameInput by remember { mutableStateOf("") }
    var openingCapitalInput by remember { mutableStateOf("") }

    var showShiftReportDialog by remember { mutableStateOf<ShiftLog?>(null) }
    var showActiveReportDialog by remember { mutableStateOf(false) }

    var isScanningBluetooth by remember { mutableStateOf(false) }
    var scannedPrinters by remember { mutableStateOf<List<String>>(emptyList()) }
    val selectedPaperSize by viewModel.mainPaperSize.collectAsStateWithLifecycle()
    val kitchenPaperSize by viewModel.kitchenPaperSize.collectAsStateWithLifecycle()

    var shiftToDelete by remember { mutableStateOf<ShiftLog?>(null) }
    var showClearDataConfirmation by remember { mutableStateOf(false) }
    var showHelpGuideDialog by remember { mutableStateOf(false) }

    val isBackupRestoreLoading by viewModel.isBackupRestoreLoading.collectAsStateWithLifecycle()
    var showRestoreConfirmationDialog by remember { mutableStateOf(false) }
    var selectedRestoreZipUri by remember { mutableStateOf<Uri?>(null) }

    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedRestoreZipUri = uri
            showRestoreConfirmationDialog = true
        }
    }

    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_app_prefs", android.content.Context.MODE_PRIVATE) }
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var isCheckingPrinterConnection by remember { mutableStateOf(false) }
    var printerConnectionStatus by remember { mutableStateOf<Boolean?>(null) }

    // Nearby devices permission state for bluetooth printing
    var showBluetoothPermissionExplanationDialog by remember { mutableStateOf(false) }
    var onPermissionGrantedAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val bluetoothPermissions = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
        arrayOf(
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT
        )
    } else {
        arrayOf(
            android.Manifest.permission.BLUETOOTH,
            android.Manifest.permission.BLUETOOTH_ADMIN,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissionsMap ->
        val allGranted = permissionsMap.values.all { it }
        if (allGranted) {
            Toast.makeText(context, "تم منح صلاحيات البلوتوث بنجاح! يمكنك الآن البحث والاتصال بالطابعة.", Toast.LENGTH_SHORT).show()
            onPermissionGrantedAction?.invoke()
        } else {
            Toast.makeText(context, "عذراً، لم يتم منح صلاحيات البلوتوث المجاورة. يرجى تفعيلها من الإعدادات للتمكن من البحث والطباعة.", Toast.LENGTH_LONG).show()
        }
        onPermissionGrantedAction = null
    }

    val checkAndRunBluetoothAction = { action: () -> Unit ->
        val missingPermissions = bluetoothPermissions.filter {
            androidx.core.content.ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missingPermissions.isEmpty()) {
            action()
        } else {
            onPermissionGrantedAction = action
            showBluetoothPermissionExplanationDialog = true
        }
    }

    // Section expansion states
    var isPOSSectionExpanded by remember { mutableStateOf(false) }
    var isPrinterSectionExpanded by remember { mutableStateOf(false) }
    var isArchiveSectionExpanded by remember { mutableStateOf(false) }

    // Find active shift
    val activeShift by remember {
        derivedStateOf { shiftLogs.firstOrNull { it.status == "مفتوحة" } }
    }
    val currentActiveShift = activeShift

    val allExpenses by viewModel.expenses.collectAsStateWithLifecycle()

    // Live calculations for active shift
    val liveSalesAndStats by remember {
        derivedStateOf {
            val shift = activeShift
            if (shift == null) {
                Triple(0.0, 0.0, 0.0)
            } else {
                val shiftInvoices = invoices.filter { it.shiftId == shift.id && it.status != "ملغاة" }
                val sales = shiftInvoices.sumOf { it.totalAmount }
                val cashSales = shiftInvoices.filter { it.paymentMethod == "نقدي" }.sumOf { it.totalAmount }
                val invoiceIds = shiftInvoices.map { it.invoiceNumber }.toSet()
                val shiftItems = allInvoiceItems.filter { it.invoiceNumber in invoiceIds }
                val profit = shiftItems.sumOf { (it.productPrice - it.productCost) * it.quantity }
                Triple(sales, profit, cashSales)
            }
        }
    }
    val liveSales by remember { derivedStateOf { liveSalesAndStats.first } }
    val liveProfit by remember { derivedStateOf { liveSalesAndStats.second } }
    val liveCashSales by remember { derivedStateOf { liveSalesAndStats.third } }

    val cancelledInvoicesForReport by remember {
        derivedStateOf {
            val shift = activeShift
            if (shift == null) {
                emptyList<Invoice>()
            } else {
                invoices.filter { it.shiftId == shift.id && it.status == "ملغاة" }
            }
        }
    }

    val activeExpenses by remember {
        derivedStateOf {
            val shift = activeShift
            if (shift == null) {
                emptyList()
            } else {
                allExpenses.filter { it.shiftId == shift.id }
            }
        }
    }
    val liveExpenses by remember { derivedStateOf { activeExpenses.sumOf { it.amount } } }

    var activeSubScreen by remember { mutableStateOf<String?>(null) }

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        if (activeSubScreen == "menu") {
            MenuScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(POSBackground)
            ) {
            // Royal Navy Header Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(POSPrimary)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "الإعدادات العامة",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تعديل خيارات الكاشير، الطابعة، ومزامنة البيانات",
                            fontSize = 13.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Settings Cog Icon inside a circular background
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = POSAccent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // 0) Super Admin Client Management Section (Only visible for Super Admin)
                if (isSuperAdmin || activeUser == "ali") {
                    item {
                        SuperAdminClientManagementCard(
                            viewModel = viewModel,
                            clientAccounts = clientAccounts
                        )
                    }
                }

                // A) Section 1: "إعدادات نقطة البيع"
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Column {
                            // Header Row (Clickable)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isPOSSectionExpanded = !isPOSSectionExpanded }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Colored Square Icon
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFE0F2FE), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PointOfSale,
                                            contentDescription = null,
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "إعدادات نقطة البيع والوردية",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = if (currentActiveShift != null) "الوردية مفتوحة ونشطة" else "الوردية مغلقة حالياً",
                                            fontSize = 12.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isPOSSectionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (isPOSSectionExpanded) {
                                Divider(color = LightGrayBg, thickness = 1.dp)
                                
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(10.dp)
                                                    .background(if (currentActiveShift != null) POSSuccess else POSDanger, CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (currentActiveShift != null) "نقطة البيع: مفتوحة ونشطة" else "نقطة البيع: مغلقة",
                                                fontWeight = FontWeight.Black,
                                                fontSize = 14.sp,
                                                color = Color.Black
                                            )
                                        }

                                        if (currentActiveShift != null) {
                                            Button(
                                                onClick = {
                                                    if (isDemo) {
                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        showActiveReportDialog = true
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                                                shape = RoundedCornerShape(20.dp),
                                                modifier = Modifier.testTag("toggle_shift_button")
                                            ) {
                                                Text("إغلاق نقطة البيع", fontWeight = FontWeight.Black, color = Color.White, fontSize = 13.sp)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    if (isDemo) {
                                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        shiftNameInput = if (activeUser == "ali") "علي" else if (activeUser == "1") "كاشير 1" else activeUser
                                                        openingCapitalInput = "150000"
                                                        showOpenShiftDialog = true
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = POSSuccess),
                                                shape = RoundedCornerShape(20.dp),
                                                modifier = Modifier.testTag("toggle_shift_button")
                                            ) {
                                                Text("فتح نقطة البيع", fontWeight = FontWeight.Black, color = Color.White, fontSize = 13.sp)
                                            }
                                        }
                                    }

                                    if (currentActiveShift != null) {
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Divider(color = LightGrayBg, thickness = 1.dp)
                                        Spacer(modifier = Modifier.height(12.dp))

                                        Text(
                                            text = "اسم الكاشير: ${currentActiveShift.shiftName}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 14.sp,
                                            color = Color.Black
                                        )

                                        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                                        Text(
                                            text = "وقت البدء: ${sdf.format(Date(currentActiveShift.startTime))}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextMuted,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )

                                        Spacer(modifier = Modifier.height(16.dp))

                                        // Stats Row
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            // Opening Capital
                                            Card(
                                                modifier = Modifier.weight(1f),
                                                colors = CardDefaults.cardColors(containerColor = POSBackground),
                                                shape = RoundedCornerShape(20.dp),
                                                border = BorderStroke(1.dp, POSBorder)
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp)) {
                                                    Text("الرأسمال الافتتاحي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = formatIraqiDinar(currentActiveShift.openingCapital),
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                }
                                            }

                                            // Sales
                                            Card(
                                                modifier = Modifier.weight(1f),
                                                colors = CardDefaults.cardColors(containerColor = POSBackground),
                                                shape = RoundedCornerShape(20.dp),
                                                border = BorderStroke(1.dp, POSBorder)
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp)) {
                                                    Text("إجمالي المبيعات", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = formatIraqiDinar(liveSales),
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // C) Menu Management Section
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp))
                            .clickable { activeSubScreen = "menu" }
                            .testTag("settings_menu_management_card"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Orange/Gold Square Icon
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFFEF3C7), RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RestaurantMenu,
                                        contentDescription = null,
                                        tint = POSWarning,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "إدارة المنيو والوجبات والأقسام",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = "تعديل، إضافة وحذف الأقسام والوجبات والأسعار",
                                        fontSize = 12.sp,
                                        color = TextMuted,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowLeft,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                // B) Section 2: "إعدادات الطابعة والاتصال"
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Column {
                            // Header Row (Clickable)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isPrinterSectionExpanded = !isPrinterSectionExpanded }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Colored Square Icon
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFDCFCE7), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Print,
                                            contentDescription = null,
                                            tint = POSSuccess,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "إعدادات الطابعة والاتصال البلوتوث",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = if (printerName.contains("الافتراضية")) "لم يتم ربط طابعة بعد" else "مرتبطة بـ $printerName",
                                            fontSize = 12.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isPrinterSectionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (isPrinterSectionExpanded) {
                                Divider(color = LightGrayBg, thickness = 1.dp)

                                Column(modifier = Modifier.padding(18.dp)) {
                                    // 1. MAIN PRINTER CARD
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 12.dp),
                                        colors = CardDefaults.cardColors(containerColor = POSBackground),
                                        shape = RoundedCornerShape(20.dp),
                                        border = BorderStroke(1.dp, POSBorder)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .background(Color(0xFFE0F2FE), RoundedCornerShape(20.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Print,
                                                        contentDescription = null,
                                                        tint = Color(0xFF0284C7),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(
                                                        text = "طابعة الكاشير الأساسية (الفواتير)",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = printerName.ifBlank { "لم يتم التعيين بعد" },
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextDark
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Divider(color = POSBorder, thickness = 0.5.dp)
                                            Spacer(modifier = Modifier.height(8.dp))

                                            // Real-time Status Display
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "حالة الاتصال: ",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextMuted
                                                )
                                                Text(
                                                    text = mainPrinterStatus,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.Black
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.startDiscoveryForMainPrinter()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1.5f),
                                                    enabled = !isScanningMainPrinter
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        if (isScanningMainPrinter) {
                                                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 1.5.dp)
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("جاري البحث...", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                        } else {
                                                            Text("بحث عن طابعة", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Black)
                                                        }
                                                    }
                                                }

                                                OutlinedButton(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.testConnectionForMainPrinter()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        containerColor = Color.White,
                                                        contentColor = Color.Black
                                                    ),
                                                    border = BorderStroke(1.dp, POSBorder),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("فحص اتصال", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Black)
                                                }
                                            }

                                            // Scanning progress
                                            if (isScanningMainPrinter) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = POSPrimary)
                                            }

                                            // Discovered list
                                            if (discoveredMainPrinters.isNotEmpty() && !isScanningMainPrinter) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text("اختر الطابعة المناسبة للحفظ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                                                Card(
                                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                                    shape = RoundedCornerShape(20.dp),
                                                    border = BorderStroke(1.dp, POSBorder)
                                                ) {
                                                    Column {
                                                        discoveredMainPrinters.forEach { deviceString ->
                                                            Row(
                                                                 modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .clickable {
                                                                        viewModel.updatePrinterName(deviceString)
                                                                        Toast.makeText(context, "تم ربط طابعة الكاشير بنجاح", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                    .padding(10.dp),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(text = deviceString, fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                                                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                                                            }
                                                            Divider(color = LightGrayBg, thickness = 0.5.dp)
                                                        }
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))
                                            Divider(color = POSBorder, thickness = 0.5.dp)
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.testPrintForPrinter(isKitchen = false)
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("طباعة تجريبية", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Black)
                                                }

                                                OutlinedButton(
                                                    onClick = {
                                                        viewModel.disconnectPrinter(isKitchen = false)
                                                        Toast.makeText(context, "تم فصل طابعة الكاشير بنجاح", Toast.LENGTH_SHORT).show()
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        containerColor = Color.White,
                                                        contentColor = POSDanger
                                                    ),
                                                    border = BorderStroke(1.dp, POSDanger),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("فصل الطابعة", fontSize = 11.sp, color = POSDanger, fontWeight = FontWeight.Black)
                                                }
                                            }
                                        }
                                    }

                                    // 2. KITCHEN PRINTER CARD
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)), // Warm tint
                                        shape = RoundedCornerShape(20.dp),
                                        border = BorderStroke(1.dp, Color(0xFFFDE68A))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .background(Color(0xFFFEF3C7), RoundedCornerShape(20.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.RestaurantMenu,
                                                        contentDescription = null,
                                                        tint = POSWarning,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(
                                                        text = "طابعة المطبخ المنفصلة (الطلبات والأكل)",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = selectedKitchenPrinterName.ifBlank { "لم يتم التعيين بعد" },
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFB45309)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Divider(color = Color(0xFFFDE68A), thickness = 0.5.dp)
                                            Spacer(modifier = Modifier.height(8.dp))

                                            // Real-time Status Display
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "حالة الاتصال: ",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFB45309).copy(alpha = 0.8f)
                                                )
                                                Text(
                                                    text = kitchenPrinterStatus,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.Black
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.startDiscoveryForKitchenPrinter()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1.5f),
                                                    enabled = !isScanningKitchenPrinter
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        if (isScanningKitchenPrinter) {
                                                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 1.5.dp)
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("جاري البحث...", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                        } else {
                                                            Text("بحث عن طابعة", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Black)
                                                        }
                                                    }
                                                }

                                                OutlinedButton(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.testConnectionForKitchenPrinter()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        containerColor = Color.White,
                                                        contentColor = Color.Black
                                                    ),
                                                    border = BorderStroke(1.dp, POSBorder),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("فحص اتصال", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Black)
                                                }
                                            }

                                            // Scanning progress
                                            if (isScanningKitchenPrinter) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = POSWarning)
                                            }

                                            // Discovered list
                                            if (discoveredKitchenPrinters.isNotEmpty() && !isScanningKitchenPrinter) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text("اختر طابعة المطبخ للحفظ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                                                Card(
                                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                                    shape = RoundedCornerShape(20.dp),
                                                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                                                ) {
                                                    Column {
                                                        discoveredKitchenPrinters.forEach { deviceString ->
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .clickable {
                                                                        viewModel.updateSelectedKitchenPrinterName(deviceString)
                                                                        Toast.makeText(context, "تم ربط طابعة المطبخ بنجاح", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                    .padding(10.dp),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(text = deviceString, fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                                                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null, tint = POSWarning, modifier = Modifier.size(16.dp))
                                                            }
                                                            Divider(color = LightGrayBg, thickness = 0.5.dp)
                                                        }
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))
                                            Divider(color = Color(0xFFFDE68A), thickness = 0.5.dp)
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        checkAndRunBluetoothAction {
                                                            viewModel.testPrintForPrinter(isKitchen = true)
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("طباعة تجريبية", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Black)
                                                }

                                                OutlinedButton(
                                                    onClick = {
                                                        viewModel.disconnectPrinter(isKitchen = true)
                                                        Toast.makeText(context, "تم فصل طابعة المطبخ بنجاح", Toast.LENGTH_SHORT).show()
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        containerColor = Color.White,
                                                        contentColor = POSDanger
                                                    ),
                                                    border = BorderStroke(1.dp, POSDanger),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("فصل الطابعة", fontSize = 11.sp, color = POSDanger, fontWeight = FontWeight.Black)
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Divider(color = LightGrayBg, thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Paper Size toggles (58mm / 80mm)
                                    Text("عرض ورق طابعة الكاشير (الأساسية)", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        listOf("58mm", "80mm").forEach { size ->
                                            val isSelected = selectedPaperSize == size
                                            Card(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        viewModel.updateMainPaperSize(size)
                                                        Toast.makeText(context, "تم تحديد مقاس ورق طابعة الكاشير: $size", Toast.LENGTH_SHORT).show()
                                                    },
                                                shape = RoundedCornerShape(20.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isSelected) POSPrimary else Color.White
                                                ),
                                                border = if (isSelected) null else BorderStroke(1.dp, POSBorder)
                                            ) {
                                                Box(modifier = Modifier.fillMaxWidth().padding(10.dp), contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = size,
                                                        color = if (isSelected) Color.White else Color.Black,
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 14.sp
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Divider(color = LightGrayBg, thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Text Thickness settings
                                    Text("سمك خط نصوص الطباعة والوصل", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(
                                            Triple("normal", "عادي", "حجم افتراضي"),
                                            Triple("bold", "غامق", "خط سميك"),
                                            Triple("extra_bold", "عريض جداً", "أقصى سماكة")
                                        ).forEach { (thicknessVal, arabicLabel, desc) ->
                                            val isSelected = textThickness == thicknessVal
                                            Card(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        viewModel.updateTextThickness(thicknessVal)
                                                        Toast.makeText(context, "تم تغيير سمك الخط إلى: $arabicLabel", Toast.LENGTH_SHORT).show()
                                                    },
                                                shape = RoundedCornerShape(20.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isSelected) POSPrimary else Color.White
                                                ),
                                                border = if (isSelected) null else BorderStroke(1.dp, POSBorder)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    Text(
                                                        text = arabicLabel,
                                                        color = if (isSelected) Color.White else Color.Black,
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 12.sp
                                                    )
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = desc,
                                                        color = if (isSelected) Color.White.copy(alpha = 0.7f) else TextMuted,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Divider(color = LightGrayBg, thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Kitchen Receipt Toggle (Switch)
                                    val isKitchenPrinterEnabled by viewModel.isKitchenPrinterEnabled.collectAsStateWithLifecycle()
                                     val isKitchenOptionalEnabled by viewModel.isKitchenOptionalEnabled.collectAsStateWithLifecycle()
                                     val selectedKitchenPrinterName by viewModel.selectedKitchenPrinterName.collectAsStateWithLifecycle()
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(POSBackground, RoundedCornerShape(20.dp))
                                            .border(BorderStroke(1.dp, POSBorder), RoundedCornerShape(20.dp))
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "تفعيل طابعة المطبخ المنفصلة (عبر البلوتوث)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                color = Color.Black
                                            )
                                            Text(
                                                text = if (isKitchenPrinterEnabled) "نشط: يرسل الطلب تلقائياً إلى طابعة المطبخ المنفصلة" else "غير نشط: لا توجد طابعة مطبخ منفصلة",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TextMuted,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }
                                        androidx.compose.material3.Switch(
                                            checked = isKitchenPrinterEnabled,
                                             onCheckedChange = { viewModel.updateIsKitchenPrinterEnabled(it) },
                                             colors = androidx.compose.material3.SwitchDefaults.colors(
                                                 checkedThumbColor = Color.White,
                                                 checkedTrackColor = POSPrimary,
                                                 uncheckedThumbColor = TextMuted,
                                                 uncheckedTrackColor = POSBorder
                                             )
                                         )
                                     }

                                     // Display current selected kitchen printer if enabled
                                     if (isKitchenPrinterEnabled) {
                                         Spacer(modifier = Modifier.height(8.dp))
                                         Card(
                                             modifier = Modifier.fillMaxWidth(),
                                             colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)), // Warm yellow card
                                             shape = RoundedCornerShape(20.dp),
                                             border = BorderStroke(1.dp, Color(0xFFF59E0B))
                                         ) {
                                             Row(
                                                 modifier = Modifier.padding(12.dp),
                                                 verticalAlignment = Alignment.CenterVertically
                                             ) {
                                                 Icon(Icons.Default.Print, contentDescription = null, tint = POSWarning, modifier = Modifier.size(20.dp))
                                                 Spacer(modifier = Modifier.width(8.dp))
                                                 Text(
                                                     text = if (selectedKitchenPrinterName.isEmpty()) 
                                                         "لم يتم تحديد طابعة المطبخ المنفصلة بعد. يرجى اختيارها من أجهزة البحث" 
                                                         else "طابعة المطبخ المعينة: $selectedKitchenPrinterName",
                                                     fontSize = 12.sp,
                                                     fontWeight = FontWeight.Bold,
                                                     color = Color(0xFFB45309)
                                                 )
                                             }
                                         }

                                         Spacer(modifier = Modifier.height(10.dp))
                                         Text("عرض ورق طابعة المطبخ", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                         Spacer(modifier = Modifier.height(6.dp))
                                         Row(
                                             modifier = Modifier.fillMaxWidth(),
                                             horizontalArrangement = Arrangement.spacedBy(12.dp)
                                         ) {
                                             listOf("58mm", "80mm").forEach { size ->
                                                 val isSelected = kitchenPaperSize == size
                                                 Card(
                                                     modifier = Modifier
                                                         .weight(1f)
                                                         .clickable {
                                                             viewModel.updateKitchenPaperSize(size)
                                                             Toast.makeText(context, "تم تحديد مقاس ورق طابعة المطبخ: $size", Toast.LENGTH_SHORT).show()
                                                         },
                                                     shape = RoundedCornerShape(20.dp),
                                                     colors = CardDefaults.cardColors(
                                                         containerColor = if (isSelected) POSPrimary else Color.White
                                                     ),
                                                     border = if (isSelected) null else BorderStroke(1.dp, POSBorder)
                                                 ) {
                                                     Box(modifier = Modifier.fillMaxWidth().padding(10.dp), contentAlignment = Alignment.Center) {
                                                         Text(
                                                             text = size,
                                                             color = if (isSelected) Color.White else Color.Black,
                                                             fontWeight = FontWeight.Black,
                                                             fontSize = 14.sp
                                                         )
                                                     }
                                                 }
                                             }
                                         }
                                     }

                                     // 2. Integrated kitchen printing option (Only shows up when Separate Kitchen Printer is disabled)
                                     if (!isKitchenPrinterEnabled) {
                                         Spacer(modifier = Modifier.height(12.dp))
                                         Row(
                                             modifier = Modifier
                                                 .fillMaxWidth()
                                                 .background(Color(0xFFF0FDF4), RoundedCornerShape(20.dp)) // Minty green alert layout
                                                 .border(BorderStroke(1.dp, Color(0xFFBBF7D0)), RoundedCornerShape(20.dp))
                                                 .padding(14.dp),
                                             horizontalArrangement = Arrangement.SpaceBetween,
                                             verticalAlignment = Alignment.CenterVertically
                                         ) {
                                             Column(modifier = Modifier.weight(1f)) {
                                                 Text(
                                                     text = "طباعة وصل المطبخ من الطابعة الأساسية",
                                                     fontSize = 13.sp,
                                                     fontWeight = FontWeight.Black,
                                                     color = Color.Black
                                                 )
                                                 Text(
                                                     text = "توليد طباعة وصل المطبخ تعاقبياً خلف الفاتورة من نفس الطابعة لتوفير الورق والجهد",
                                                     fontSize = 11.sp,
                                                     fontWeight = FontWeight.Bold,
                                                     color = POSSuccess,
                                                     modifier = Modifier.padding(top = 2.dp)
                                                 )
                                             }
                                             androidx.compose.material3.Switch(
                                                 checked = isKitchenOptionalEnabled,
                                                 onCheckedChange = { viewModel.updateIsKitchenOptionalEnabled(it) },
                                                 colors = androidx.compose.material3.SwitchDefaults.colors(
                                                     checkedThumbColor = Color.White,
                                                     checkedTrackColor = POSSuccess,
                                                     uncheckedThumbColor = TextMuted,
                                                     uncheckedTrackColor = POSBorder
                                                 )
                                             )
                                         }
                                     }

                                                                           /* // Kitchen Phone setting for WhatsApp orders
                                     var kitchenPhoneInput by remember { 
                                         mutableStateOf(prefs.getString("kitchen_phone", "") ?: "") 
                                     }
                                     Spacer(modifier = Modifier.height(16.dp))
                                     Text(
                                         text = "",
                                         fontSize = 12.sp,
                                         fontWeight = FontWeight.Black,
                                         color = Color.Black
                                     )
                                     Spacer(modifier = Modifier.height(6.dp))
                                     OutlinedTextField(
                                         value = kitchenPhoneInput,
                                         onValueChange = { input ->
                                             val filtered = input.filter { it in '0'..'9' }
                                             if (filtered.length <= 11) {
                                                 kitchenPhoneInput = filtered
                                                 prefs.edit().putString("kitchen_phone", filtered).apply()
                                             }
                                         },
                                         placeholder = { Text("مثال: 07810936407", fontSize = 13.sp) },
                                         modifier = Modifier.fillMaxWidth(),
                                         keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                         shape = RoundedCornerShape(10.dp),
                                         singleLine = true,
                                         colors = OutlinedTextFieldDefaults.colors(
                                             focusedBorderColor = POSPrimary,
                                             unfocusedBorderColor = POSBorder,
                                             focusedContainerColor = Color.White,
                                             unfocusedContainerColor = Color.White
                                         )
                                     )

                                                                           */ // Dummy code to absorb original switch properties safely
                                     val isDummyActive = false
                                     /*
                                     if (isDummyActive) {
                                         androidx.compose.material3.Switch(
                                             checked = false,
                                             onCheckedChange = { viewModel.updateIsKitchenPrinterEnabled(it) },
                                            onCheckedChange = { viewModel.updateIsKitchenPrinterEnabled(it) },
                                            colors = androidx.compose.material3.SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = POSPrimary,
                                                uncheckedThumbColor = TextMuted,
                                                uncheckedTrackColor = POSBorder
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Divider(color = LightGrayBg, thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    */
                                }
                            }
                        }
                    }
                }

                // C) Section 3: "سجل الحسابات والأرشيف"
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Column {
                            // Header Row (Clickable)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isArchiveSectionExpanded = !isArchiveSectionExpanded }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Colored Square Icon
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFF3E8FF), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Archive,
                                            contentDescription = null,
                                            tint = Color(0xFFA855F7),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "سجل الحسابات والورديات المؤرشفة",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "عرض وتصفح أرشيف الفواتير والتقارير",
                                            fontSize = 12.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isArchiveSectionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (isArchiveSectionExpanded) {
                                Divider(color = LightGrayBg, thickness = 1.dp)

                                Column(modifier = Modifier.padding(18.dp)) {
                                    val closedShifts = remember(shiftLogs) { shiftLogs.filter { it.status == "مغلقة" } }
                                    if (closedShifts.isEmpty()) {
                                        Text(
                                            text = "لا توجد سجلات نقاط بيع مغلقة سابقة في الأرشيف.",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextMuted,
                                            modifier = Modifier.padding(8.dp)
                                        )
                                    } else {
                                        closedShifts.forEachIndexed { idx, log ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { showShiftReportDialog = log }
                                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = log.shiftName, fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                                    val startSdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                                                    Text(text = "تاريخ نقطة البيع: ${startSdf.format(Date(log.startTime))}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                                                }

                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(horizontalAlignment = Alignment.End) {
                                                        Text(
                                                            text = "المبيعات: " + formatIraqiDinar(log.totalSales),
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color.Black
                                                        )
                                                    }

                                                    IconButton(
                                                        onClick = {
                                                            shiftToDelete = log
                                                        }
                                                    ) {
                                                        Icon(Icons.Default.Delete, contentDescription = "حذف نقطة البيع", tint = POSDanger)
                                                    }
                                                }
                                            }
                                            if (idx < closedShifts.size - 1) {
                                                Divider(color = LightGrayBg, thickness = 0.5.dp)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(24.dp))
                                    Divider(color = LightGrayBg, thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Fully isolated Danger Zone / System maintenance nested safely at the bottom of Section C
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = POSDanger.copy(alpha = 0.05f)),
                                        shape = RoundedCornerShape(20.dp),
                                        border = BorderStroke(1.dp, POSDanger.copy(alpha = 0.2f))
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Warning, contentDescription = null, tint = POSDanger, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "منطقة الخطر والصيانة",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = POSDanger
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "مسح جميع البيانات سيقوم بتفريغ الكاشير تماماً وإعادة تهيئة النظام لقيم المصنع الافتراضية للوجبات والأقسام.",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TextMuted,
                                                lineHeight = 18.sp
                                            )
                                            Spacer(modifier = Modifier.height(14.dp))

                                            Button(
                                                onClick = { showClearDataConfirmation = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text("مسح جميع البيانات بالكامل", fontWeight = FontWeight.Black, color = Color.White)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section: "النسخ الاحتياطي واستعادة البيانات" (Backup & Restore)
                item {
                    var isBackupSectionExpanded by remember { mutableStateOf(true) }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Column {
                            // Header Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isBackupSectionExpanded = !isBackupSectionExpanded }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFEFF6FF), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CloudSync,
                                            contentDescription = null,
                                            tint = POSPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "النسخ الاحتياطي واستعادة البيانات",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "تصدير واسترجاع المبيعات والمنيو والإعدادات (Offline-First)",
                                            fontSize = 12.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isBackupSectionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (isBackupSectionExpanded) {
                                Divider(color = LightGrayBg, thickness = 1.dp)

                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    if (isBackupRestoreLoading) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                                            shape = RoundedCornerShape(16.dp),
                                            border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(16.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(24.dp),
                                                    color = POSPrimary,
                                                    strokeWidth = 2.5.dp
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text(
                                                    text = "جاري تنفيذ عملية النسخ الاحتياطي / الاستعادة محلياً...",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = POSPrimary
                                                )
                                            }
                                        }
                                    }

                                    // 1. Export Backup Button
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable(enabled = !isBackupRestoreLoading) {
                                                viewModel.exportFullBackup(
                                                    onSuccess = { zipFile ->
                                                        Toast.makeText(context, "تم تصدير النسخة الاحتياطية بنجاح إلى مجلد Downloads", Toast.LENGTH_LONG).show()
                                                        com.example.utils.BackupManager.shareBackupFile(context, zipFile)
                                                    },
                                                    onError = { errorMsg ->
                                                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                                    }
                                                )
                                            },
                                        colors = CardDefaults.cardColors(containerColor = POSBackground),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, POSBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .background(Color(0xFFDCFCE7), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CloudUpload,
                                                        contentDescription = null,
                                                        tint = Color(0xFF16A34A),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "إنشاء نسخة احتياطية (Export Backup)",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = "تجميع كافة البيانات والصور والإعدادات في ملف (.zip) واحد وحفظه أو مشاركته",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextMuted
                                                    )
                                                }
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFF16A34A), RoundedCornerShape(20.dp))
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = "تصدير الآن",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }

                                    // 2. Restore Backup Button
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable(enabled = !isBackupRestoreLoading) {
                                                restoreBackupLauncher.launch("application/zip")
                                            },
                                        colors = CardDefaults.cardColors(containerColor = POSBackground),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, POSBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .background(Color(0xFFFEF3C7), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CloudDownload,
                                                        contentDescription = null,
                                                        tint = Color(0xFFD97706),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "استرجاع نسخة احتياطية (Restore Backup)",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = "اختيار ملف (.zip) من الهاتف لاستعادة المبيعات والمنيو والإعدادات فوراً",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextMuted
                                                    )
                                                }
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFD97706), RoundedCornerShape(20.dp))
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = "استرجاع",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // D) Section 4: "الدعم والتعليمات" (Help & Support)
                item {
                    var isHelpSectionExpanded by remember { mutableStateOf(true) }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = null
                    ) {
                        Column {
                            // Header Row (Clickable)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isHelpSectionExpanded = !isHelpSectionExpanded }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Colored Square Icon (Emerald / Green)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFDCFCE7), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SupportAgent,
                                            contentDescription = null,
                                            tint = Color(0xFF16A34A),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "الدعم والتعليمات",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "دليل الاستخدام والتدريب والتواصل الفني",
                                            fontSize = 12.sp,
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isHelpSectionExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (isHelpSectionExpanded) {
                                Divider(color = LightGrayBg, thickness = 1.dp)

                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Option 1: "دليل الاستخدام والتعليمات"
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { showHelpGuideDialog = true },
                                        colors = CardDefaults.cardColors(containerColor = POSBackground),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, POSBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .background(Color(0xFFE0F2FE), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.MenuBook,
                                                        contentDescription = null,
                                                        tint = POSPrimary,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "دليل الاستخدام والتعليمات",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = "شرح خطوة بخطوة لكل ميزات الوردية والمنيو والطباعة والمبيعات",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextMuted
                                                    )
                                                }
                                            }
                                            Icon(
                                                imageVector = Icons.Default.ChevronLeft,
                                                contentDescription = null,
                                                tint = TextMuted,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    // Option 2: "المساعدة والتدريب الفني"
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                try {
                                                    val intent = Intent(
                                                        Intent.ACTION_VIEW,
                                                        Uri.parse("https://api.whatsapp.com/send?phone=9647803453936")
                                                    )
                                                    context.startActivity(intent)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "تعذر فتح الواتساب أو الرابط", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, Color(0xFFBBF7D0))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .background(Color(0xFFDCFCE7), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Chat,
                                                        contentDescription = null,
                                                        tint = Color(0xFF16A34A),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "المساعدة والتدريب الفني",
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = "تواصل مباشر مع الدعم الفني والتدريب الفوري عبر الواتساب",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextMuted
                                                    )
                                                }
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFF22C55E), RoundedCornerShape(20.dp))
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = "تواصل الآن",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        if (shiftToDelete != null) {
            AlertDialog(
                onDismissRequest = { shiftToDelete = null },
                title = { Text("تأكيد حذف نقطة البيع", fontWeight = FontWeight.Black, color = Color.Black) },
                text = { Text("هل أنت متأكد من حذف هذا السجل بالكامل؟ سيتم مسح الأرشيف نهائياً ولا يمكن استرجاعه.", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black) },
                confirmButton = {
                    Button(
                        onClick = {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                viewModel.deleteShiftLog(shiftToDelete!!)
                                Toast.makeText(context, "تم حذف السجل بنجاح", Toast.LENGTH_SHORT).show()
                            }
                            shiftToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = POSDanger)
                    ) {
                        Text("نعم، احذف السجل", fontWeight = FontWeight.Black, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { shiftToDelete = null }) {
                        Text("إلغاء", fontWeight = FontWeight.Black, color = Color.DarkGray)
                    }
                },
                containerColor = POSSurface
            )
        }

        if (showClearDataConfirmation) {
            AlertDialog(
                onDismissRequest = { showClearDataConfirmation = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = POSDanger,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تدمير وتطهير شامل للنظام",
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "تحذير أمني حاسم ومطلق:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = LightGrayBg
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "بناءً على طلبك، سيتم الآن مسح كافة الجداول وقواعد البيانات نهائياً، وتصفير الإعدادات، وحذف كافة الصور والملفات المحلية. سينطفئ التطبيق ويعاد تشغيله فارغاً ومطهراً بالكامل.",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSBorder,
                            lineHeight = 20.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هذا الإجراء فوري وغير قابل للتراجع!",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFCA5A5)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "جاري تطهير النظام بالكامل وإعادة التشغيل...", Toast.LENGTH_LONG).show()
                                viewModel.clearAllSystemData()
                            }
                            showClearDataConfirmation = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("تطهير النظام وإعادة التشغيل", fontWeight = FontWeight.Black, color = Color.White, fontSize = 12.sp)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showClearDataConfirmation = false },
                        border = BorderStroke(1.dp, Color(0xFF475569)),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("إلغاء وتراجع", fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                },
                containerColor = POSPrimary,
                textContentColor = Color.White,
                titleContentColor = Color.White
            )
        }

        // Bluetooth Permission Explanation Dialog
        if (showBluetoothPermissionExplanationDialog) {
            Dialog(onDismissRequest = { 
                showBluetoothPermissionExplanationDialog = false 
                onPermissionGrantedAction = null
            }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    border = BorderStroke(2.dp, Color.Black),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = POSPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "طلب صلاحية الأجهزة المجاورة",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هل تريد السماح لتطبيق الكاشير بالعثور على طابعات الفواتير الحرارية المجاورة والاقتران بها لطباعة فواتير مبيعات المطعم مباشرة عبر البلوتوث؟",
                            fontSize = 14.sp,
                            color = Color(0xFF475569),
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { 
                                    showBluetoothPermissionExplanationDialog = false 
                                    onPermissionGrantedAction = null
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.5.dp, Color.Black)
                            ) {
                                Text("إلغاء", color = Color.Black, fontWeight = FontWeight.Black)
                            }
                            Button(
                                onClick = {
                                    showBluetoothPermissionExplanationDialog = false
                                    permissionLauncher.launch(bluetoothPermissions)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("سماح بالصلاحية", color = Color.White, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }

        // 1. Open Shift Dialog - updated labels
        if (showOpenShiftDialog) {
            Dialog(onDismissRequest = { showOpenShiftDialog = false }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    border = BorderStroke(2.dp, Color.Black),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("فتح نقطة بيع جديدة", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = shiftNameInput,
                            onValueChange = { shiftNameInput = it },
                            label = { Text("اسم الكاشير", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = openingCapitalInput,
                            onValueChange = {
                                if (it.isEmpty() || it.all { c -> c.isDigit() }) {
                                    openingCapitalInput = it
                                }
                            },
                            label = { Text("رأس المال الافتتاحي د.ع", fontWeight = FontWeight.Bold) },
                            trailingIcon = { Text("د.ع", fontWeight = FontWeight.Black, color = Color.Black) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showOpenShiftDialog = false },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color.Black)
                            ) {
                                Text("إلغاء", color = Color.Black, fontWeight = FontWeight.Black)
                            }
                            Button(
                                onClick = {
                                    if (shiftNameInput.isNotBlank() && openingCapitalInput.isNotBlank()) {
                                        viewModel.openShift(shiftNameInput, openingCapitalInput.toDoubleOrNull() ?: 0.0)
                                        showOpenShiftDialog = false
                                        Toast.makeText(context, "تم فتح نقطة بيع جديدة بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                            ) {
                                Text("فتح نقطة البيع", fontWeight = FontWeight.Black, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // 2. Active Shift Summary Close Report Dialog (No Net Profit!)
        if (showActiveReportDialog && currentActiveShift != null) {
            Dialog(onDismissRequest = { showActiveReportDialog = false }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    border = BorderStroke(2.dp, Color.Black),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "تقرير إغلاق نقطة البيع الحالية",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                        Text(text = "اسم الكاشير: ${currentActiveShift.shiftName}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Text(text = "تاريخ البدء: ${sdf.format(Date(currentActiveShift.startTime))}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                        Text(text = "تاريخ الإغلاق: ${sdf.format(Date())}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Black)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("رأس المال الافتتاحي:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(currentActiveShift.openingCapital), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المبيعات:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(liveSales), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المبيعات النقدية:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(liveCashSales), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المصاريف:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(liveExpenses), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSDanger)
                            }
                            if (cancelledInvoicesForReport.isNotEmpty()) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("الطلبات الملغاة (${cancelledInvoicesForReport.size}):", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = POSDanger)
                                    Text(formatIraqiDinar(cancelledInvoicesForReport.sumOf { it.totalAmount }), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSDanger)
                                }
                            }
                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("المبلغ المتوقع بالصندوق:", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                Text(formatIraqiDinar((currentActiveShift.openingCapital + liveCashSales) - liveExpenses), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.closeShift(currentActiveShift.id, liveSales, liveProfit)
                                        ReceiptPrinterHelper.printShiftReport(
                                            context = context,
                                            shiftName = currentActiveShift.shiftName,
                                            startTime = currentActiveShift.startTime,
                                            endTime = System.currentTimeMillis(),
                                            openingCapital = currentActiveShift.openingCapital,
                                            totalSales = liveSales,
                                            cashSales = liveCashSales,
                                            totalExpenses = liveExpenses,
                                            cancelledInvoices = cancelledInvoicesForReport
                                        )
                                        showActiveReportDialog = false
                                        Toast.makeText(context, "تم إغلاق نقطة البيع والطباعة بنجاح", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                                    border = BorderStroke(1.dp, Color.Black),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("إغلاق مع الطباعة", fontWeight = FontWeight.Black, color = Color.White, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        viewModel.closeShift(currentActiveShift.id, liveSales, liveProfit)
                                        showActiveReportDialog = false
                                        Toast.makeText(context, "تم إغلاق نقطة البيع بدون طباعة بنجاح", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = TextMuted),
                                    border = BorderStroke(1.dp, Color.Black),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("إغلاق بدون طباعة", fontWeight = FontWeight.Black, color = Color.White, fontSize = 12.sp)
                                }
                            }

                            OutlinedButton(
                                onClick = { showActiveReportDialog = false },
                                modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, Color.Black),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text("إلغاء وتراجع", color = Color.Black, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }

        // 3. Past Shift Summary Archive Report Dialog (No Net Profit!)
        if (showShiftReportDialog != null) {
            val report = showShiftReportDialog!!
            Dialog(onDismissRequest = { showShiftReportDialog = null }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    border = BorderStroke(2.dp, Color.Black),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "تقرير نقطة البيع المؤرشف",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                        Text(text = "اسم الكاشير: ${report.shiftName}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Text(text = "تاريخ البدء: ${report.startTime.let { sdf.format(Date(it)) }}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                        if (report.endTime != null) {
                            Text(text = "تاريخ الإغلاق: ${report.endTime.let { sdf.format(Date(it)) }}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Black)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("رأس المال الافتتاحي:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(report.openingCapital), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المبيعات:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Text(formatIraqiDinar(report.totalSales), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("النقدية عند الإغلاق:", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                Text(formatIraqiDinar(report.openingCapital + report.totalSales), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { showShiftReportDialog = null },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text("إغلاق النافذة", fontWeight = FontWeight.Black, color = Color.White)
                        }
                    }
                }
            }
        }

        // Restore Confirmation Dialog
        if (showRestoreConfirmationDialog && selectedRestoreZipUri != null) {
            AlertDialog(
                onDismissRequest = {
                    showRestoreConfirmationDialog = false
                    selectedRestoreZipUri = null
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = null,
                            tint = POSPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تأكيد استعادة البيانات",
                            fontWeight = FontWeight.Black,
                            color = Color.Black,
                            fontSize = 18.sp
                        )
                    }
                },
                text = {
                    Text(
                        text = "استعادة النسخة الاحتياطية ستقوم باستبدال قواعد البيانات والمنيو والمبيعات والإعدادات الحالية بالبيانات المحفوظة داخل الملف المضغوط (.zip). هل أنت متأكد من المتابعة؟",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        lineHeight = 22.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val uri = selectedRestoreZipUri
                            showRestoreConfirmationDialog = false
                            selectedRestoreZipUri = null
                            if (uri != null) {
                                viewModel.restoreFullBackup(
                                    zipUri = uri,
                                    onSuccess = {
                                        Toast.makeText(context, "تمت استعادة كافة البيانات والمنيو والإعدادات بنجاح!", Toast.LENGTH_LONG).show()
                                    },
                                    onError = { errorMsg ->
                                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("نعم، استرجع البيانات الآن", fontWeight = FontWeight.Black, color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = {
                            showRestoreConfirmationDialog = false
                            selectedRestoreZipUri = null
                        },
                        border = BorderStroke(1.dp, Color.Black),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("إلغاء", fontWeight = FontWeight.Black, color = Color.Black)
                    }
                },
                containerColor = POSSurface
            )
        }

        // 4. Help & Support Guide Dialog
        if (showHelpGuideDialog) {
            HelpGuideDialog(onDismiss = { showHelpGuideDialog = false })
        }
    }
    }
}

@Composable
fun HelpGuideDialog(onDismiss: () -> Unit) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf(
        "الوردية والبيع",
        "الطلبات وإرجاع المبالغ",
        "المصاريف والتقرير",
        "إدارة المنيو",
        "الطباعة الحرارية",
        "النسخ الاحتياطي واستعادة البيانات"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(24.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header with Title and Close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFFE0F2FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = POSPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "دليل الاستخدام والتعليمات",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black
                            )
                            Text(
                                text = "دليل شامل لشرح جميع وظائف وميزات النظام",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(POSBackground, CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable Tab Row
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    containerColor = POSBackground,
                    contentColor = POSPrimary,
                    divider = {}
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Black else FontWeight.Bold,
                                    color = if (selectedTab == index) POSPrimary else TextMuted,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Content Area for selected tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (selectedTab) {
                            0 -> ShiftAndPosHelpTab()
                            1 -> OrdersAndRefundsHelpTab()
                            2 -> ExpensesHelpTab()
                            3 -> MenuManagementHelpTab()
                            4 -> ThermalPrinterHelpTab()
                            5 -> BackupAndRestoreHelpTab()
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Close Action
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary)
                ) {
                    Text(
                        text = "فهمت، إغلاق الدليل",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ShiftAndPosHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "1",
            title = "إعدادات الوردية وصندوق العهدة",
            icon = Icons.Default.PointOfSale,
            iconTint = POSPrimary,
            bgTint = Color(0xFFF0F9FF),
            details = listOf(
                "فتح وردية جديدة وتحديد مبلغ صندوق العهدة الافتتاحي: من قسم الإعدادات العامة ➔ إعدادات نقطة البيع والوردية، اضغط على 'فتح نقطة البيع' وأدخل اسم الكاشير ومبلغ العهدة البدائي المودع في الصندوق.",
                "اختيار نوع الطلب والطاولة: في واجهة البيع يمكنك التبديل بين (صالة / سفري / سفري توصيل)، واختيار رقم الطاولة لطلبات الصالة وتأكيد الطلب.",
                "إغلاق الوردية وتصفية الحساب: عند انتهاء شفت العمل، اضغط 'إغلاق نقطة البيع' لمراجعة إجمالي المبيعات والنقد والمصاريف المطروحة والتأكد من مطابقة المبلغ الفعلي في الصندوق قبل الحفظ النهائي."
            )
        )
    }
}

@Composable
private fun OrdersAndRefundsHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "2",
            title = "إدارة الطلبات، الأرشيف، وإلغاء/حذف الفواتير (إرجاع المبلغ)",
            icon = Icons.Default.ReceiptLong,
            iconTint = Color(0xFFDC2626),
            bgTint = Color(0xFFFEF2F2),
            details = listOf(
                "استعراض قائمة الطلبات والأرشيف: يمكنك الانتقال إلى شاشة 'الأرشيف والسجلات' لمراجعة كافة الطلبات السابقة مع الوقت ورقم الفاتورة والتفاصيل.",
                "حذف طلب من القائمة وإرجاع المبلغ القديم تلقائياً: عند حذف أو إلغاء أي طلب من قائمة الطلبات، يقوم النظام تلقائياً بإرجاع المبلغ القديم وخصمه من إجمالي مبيعات اليوم وصندوق الكاشير، مع إعادة المبالغ للزبون وتحديث تقرير الوردية فوراً.",
                "عدم التلاعب وإعادة تعيين الحسابات: يضمن إلغاء الطلب مطابقة الصندوق بدقة عالية حيث يُلغى تأثير الفاتورة الملغاة على الأرباح والمبيعات الإجمالية."
            )
        )
    }
}

@Composable
private fun ExpensesHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "3",
            title = "تسجيل المصاريف والتقرير المالي",
            icon = Icons.Default.AccountBalanceWallet,
            iconTint = Color(0xFFD97706),
            bgTint = Color(0xFFFFFBEB),
            details = listOf(
                "إضافة مصاريف تشغيلية ونثرية: من قسم 'إدارة المصاريف'، يمكنك إضافة أي مصاريف خرجت من الصندوق (مشتريات خضار ومواد، صيانة، رواتب، كهرباء، إلخ) مع إدخال المبلغ والبيان.",
                "الخصم المباشر من الصندوق وصافي الأرباح: يتم خصم كافة المصاريف المسجلة مباشرة من نقدية الصندوق المتوفرة في الوردية، وتطرح من المبيعات في التقرير لحساب صافي الربح الحقيقي بدقة.",
                "سجل المصاريف والتدقيق: يتيح لك النظام تصفح ومراجعة كل بند مصروف وتاريخه وملاحظاته لضمان الشفافية المالية."
            )
        )
    }
}

@Composable
private fun MenuManagementHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "4",
            title = "إدارة المنيو والوجبات والأقسام",
            icon = Icons.Default.RestaurantMenu,
            iconTint = Color(0xFF059669),
            bgTint = Color(0xFFECFDF5),
            details = listOf(
                "إضافة قسم جديد (مثل: مشروبات، وجبات رئيسية): من شاشة إدارة المنيو اضغط على 'إضافة قسم' واكتب الاسم ليظهر فوراً في أقسام الكاشير.",
                "إضافة وجبة جديدة وتحديد السعر: اضغط على 'إضافة وجبة'، أدخل الاسم والسعر بالدينار واختر القسم التابع لها والصورة التعبيرية.",
                "تعديل الأقسام والوجبات أو حذفها: يمكنك الضغط على أيقونة التعديل أو الحذف بجانب كل وجبة أو قسم لتحديث الأسعار أو حذف المادة نهائياً."
            )
        )
    }
}

@Composable
private fun ThermalPrinterHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "5",
            title = "الطباعة الحرارية وإعدادات الطابعة",
            icon = Icons.Default.Print,
            iconTint = POSSuccess,
            bgTint = Color(0xFFF0FDF4),
            details = listOf(
                "البحث عن طابعات الفواتير عبر البلوتوث: قم بتشغيل البلوتوث والطابعة الحرارية، ثم اضغط 'بحث عن طابعة' في الإعدادات واقترن بالطابعة المطلوبة.",
                "تعيين الطابعة الافتراضية والطباعة التجريبية: اضغط 'فحص اتصال' لاختبار الربط، ثم اضغط 'طباعة تجريبية' للتأكد من المخرجات ومقاس الورق (58mm أو 80mm)."
            )
        )
    }
}

@Composable
private fun HelpItemCard(
    stepNumber: String,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    bgTint: Color,
    details: List<String>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bgTint),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, iconTint.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(iconTint, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stepNumber,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                details.forEach { detail ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "• ",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = iconTint
                        )
                        Text(
                            text = detail,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1F2937),
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrialExpiredScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(POSBackground)
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = POSDanger,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "انتهت المدة التجريبية، يرجى التواصل مع المطور: 07810936407",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
fun LoginScreen(viewModel: POSViewModel) {
    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Block hardware back button on Login screen to prevent bypass or unexpected exits
    androidx.activity.compose.BackHandler {
        (context as? android.app.Activity)?.finish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(POSBackground) // SaaS white/gray clean canvas
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
                .background(Color.White, RoundedCornerShape(20.dp))
                .border(1.dp, POSBorder, RoundedCornerShape(20.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large Bold Black Title Header (SaaS style)
            Text(
                text = "تسجيل الدخول",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "نظام إدارة المبيعات والكاشير الذكي",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Input: Username
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "اسم المستخدم",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
                OutlinedTextField(
                    value = usernameInput,
                    onValueChange = { usernameInput = it },
                    placeholder = { Text("أدخل اسم المستخدم", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth().testTag("username_input"),
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = POSPrimary,
                        unfocusedBorderColor = POSBorder,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Input: Password
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "كلمة المرور",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    placeholder = { Text("أدخل كلمة المرور", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth().testTag("password_input"),
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = POSPrimary,
                        unfocusedBorderColor = POSBorder,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    )
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Login Button - Smooth and formal (10.dp border radius)
            val isLoggingIn by viewModel.isLoggingIn.collectAsStateWithLifecycle()
            val loginErrorMessage by viewModel.loginErrorMessage.collectAsStateWithLifecycle()

            if (!loginErrorMessage.isNullOrBlank()) {
                Text(
                    text = loginErrorMessage!!,
                    color = POSDanger,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            Button(
                onClick = {
                    if (usernameInput.trim().isEmpty() || passwordInput.trim().isEmpty()) {
                        Toast.makeText(context, "يرجى إدخال اسم المستخدم وكلمة المرور", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.login(usernameInput.trim(), passwordInput.trim()) { success ->
                            if (success) {
                                Toast.makeText(context, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
                            } else {
                                val errorMsg = viewModel.loginErrorMessage.value ?: "اسم المستخدم أو كلمة المرور غير صحيحة"
                                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                enabled = !isLoggingIn,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_button"),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = POSPrimary, // Sleek deep navy SaaS style
                    contentColor = Color.White
                )
            ) {
                if (isLoggingIn) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                } else {
                    Text(
                        text = "دخول",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun BackupAndRestoreHelpTab() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        HelpItemCard(
            stepNumber = "1",
            title = "إنشاء نسخة احتياطية شاملة (Export Full Backup)",
            icon = Icons.Default.CloudUpload,
            iconTint = Color(0xFF16A34A),
            bgTint = Color(0xFFF0FDF4),
            details = listOf(
                "الضغط على 'إنشاء نسخة احتياطية': يقوم التطبيق محلياً وبسرعة فائقة بتجميع كافة المبيعات، الفواتير، الأقسام، الوجبات مع أسعارها، المصاريف، وسجل الورديات، بالإضافة إلى اللوجو والصور والإعدادات كاملة في ملف مضغوط واحد بصيغة (.zip).",
                "تسمية الملف وحفظه: يتم حفظ الملف تلقائياً في مجلد التحميلات (Downloads) بذاكرة الهاتف الداخلية مع إضافة التاريخ والوقت إلى اسم الملف.",
                "المشاركة المباشرة: تظهر نافذة المشاركة فوراً لإرسال الملف عبر الواتساب أو حفظه في وحدة التخزين السحابية (Google Drive) لضمان أمان البيانات."
            )
        )

        HelpItemCard(
            stepNumber = "2",
            title = "استرجاع النسخة الاحتياطية (Restore Backup)",
            icon = Icons.Default.CloudDownload,
            iconTint = Color(0xFFD97706),
            bgTint = Color(0xFFFEF3C7),
            details = listOf(
                "اختيار ملف النسخة الاحتياطية: اضغط على 'استرجاع نسخة احتياطية' لتفتح لك حافظة ملفات الهاتف، واختر ملف النسخة الاحتياطية (.zip).",
                "فك الضغط والتحديث الفوري: يقوم النظام بفك الضغط واستبدال قواعد البيانات المحلية (Room Database) وإعادة نسخ كافة الصور واللوجو إلى مجلد التطبيق المخصص.",
                "العمل بدون إنترنت (Offline 100%): تتم جميع العمليات محلياً على جهازك بسرعة وأمان تكسوها شاشات تحميل واضحة للتأكيد.",
                "الحماية والتحقق: في حال اختيار ملف غير صالح أو غير مضغوط بالشكل المطلوب، يظهر تنبيه فوري يمنع تضرر البيانات دون إيقاف التطبيق."
            )
        )
    }
}
