package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Design System Colors ---
val POSPrimary = Color(0xFF162544)
val POSPrimaryLight = Color(0xFF23406D)
val POSAccent = Color(0xFFF59E0B)
val POSBackground = Color(0xFFF8FAFC)
val POSSurface = Color(0xFFFFFFFF)
val POSBorder = Color(0xFFE5E7EB)
val POSSuccess = Color(0xFF10B981)
val POSWarning = Color(0xFFF59E0B)
val POSDanger = Color(0xFFEF4444)

// --- Text Colors ---
val TextDark = Color(0xFF111827) // Text Primary
val TextMuted = Color(0xFF6B7280) // Text Secondary
val CardBorder = Color(0xFFE5E7EB)
val LightGrayBg = Color(0xFFF8FAFC)
