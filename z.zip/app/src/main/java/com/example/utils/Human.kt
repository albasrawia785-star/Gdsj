package com.example.utils

object Human {
    const val RESTAURANT_NAME = "مطعم ومقهى النخبة"
    const val RESTAURANT_PHONE = "07701234567"
    
    // حساب المدير الرئيسي
    const val MANAGER_USERNAME = "ali"
    const val MANAGER_PASSWORD = "19971997"
    
    // حساب الكاشير التجريبي / الموظف
    const val CASHIER_USERNAME = "1"
    const val CASHIER_PASSWORD = "1"

    // حساب المسؤول الافتراضي الاحتياطي
    const val LOGIN_USERNAME = "admin"
    const val LOGIN_PASSWORD = "123"
}
